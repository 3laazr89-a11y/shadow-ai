package com.example.shadowingai

import android.graphics.Color as AndroidColor
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun PhraseExamplesDialog(
    phraseId: String,
    phrase: String,
    onSearchSources: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val db = remember { PhraseExamplesDatabase.getInstance(context) }
    var examples by remember(phraseId) { mutableStateOf(emptyList<PhraseExample>()) }
    var searches by remember(phraseId) { mutableStateOf(emptyList<PhraseExampleSearch>()) }
    var showAdd by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf<PhraseExample?>(null) }
    var searchToOpen by remember { mutableStateOf<PhraseExampleSearch?>(null) }
    fun refresh() {
        examples = db.getExamples(phraseId, verifiedOnly = false)
        searches = db.getSearches(phraseId)
    }
    LaunchedEffect(phraseId) { refresh() }
    val verified = examples.filter { it.verificationState == PhraseExample.STATE_VERIFIED }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080D16)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White) }
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                        Text("أمثلة العبارة المحفوظة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("قاعدة البيانات المحلية • $phraseId", color = Color(0xFF9AA6BB), fontSize = 10.sp)
                    }
                }
                Surface(Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Color(0xFF202B40), shape = RoundedCornerShape(12.dp)) {
                    Text(phrase, Modifier.padding(13.dp), color = Color(0xFFFFC56B), fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("موثّق", verified.size, Color(0xFF64D6A6), Modifier.weight(1f))
                    StatPill("قيد المراجعة", examples.count { it.verificationState == PhraseExample.STATE_PENDING }, Color(0xFFFFC56B), Modifier.weight(1f))
                    StatPill("المطلوب", 3, Color(0xFF9FA8FF), Modifier.weight(1f))
                }
                Text("مصادر بحث مخصصة لهذه العبارة", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 7.dp))
                Text("هذه روابط بحث جاهزة وليست مقاطع موثّقة. افتح النتائج واختر مقطعاً ينطق العبارة فعلاً.", color = Color(0xFF9AA6BB), fontSize = 10.sp, lineHeight = 15.sp)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(searches, key = { it.sourceId }) { search ->
                        OutlinedButton(
                            onClick = { searchToOpen = search },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(search.sourceName, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }
                Text("ثلاثة مواضع للأمثلة الموثّقة", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 7.dp))
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (0..2).forEach { slot ->
                        val item = verified.getOrNull(slot)
                        if (item == null) {
                            Surface(Modifier.fillMaxWidth(), color = Color(0xFF141F30), shape = RoundedCornerShape(12.dp)) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("المثال ${slot + 1} • لا يوجد مقطع موثّق بعد", color = Color(0xFF9AA6BB), modifier = Modifier.weight(1f), fontSize = 12.sp)
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFFFC56B))
                                }
                            }
                        } else ExampleCard(item, slot + 1, onPlay = { playing = item }, onDelete = { db.deleteExample(item.id); refresh() })
                    }
                    if (examples.any { it.verificationState != PhraseExample.STATE_VERIFIED }) {
                        Text("أمثلة تنتظر المراجعة", color = Color(0xFFFFC56B), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                        examples.filter { it.verificationState != PhraseExample.STATE_VERIFIED }.forEach { item ->
                            Surface(Modifier.fillMaxWidth(), color = Color(0xFF242331), shape = RoundedCornerShape(10.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("${item.sourceId} • ${item.url}", color = Color(0xFF9AA6BB), fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { playing = item }) { Icon(Icons.Default.PlayArrow, null); Text("معاينة", fontSize = 11.sp) }
                                        TextButton(onClick = { db.setExampleState(item.id, PhraseExample.STATE_VERIFIED); refresh() }) { Text("اعتماد كمثال موثّق", color = Color(0xFF64D6A6), fontSize = 11.sp) }
                                        TextButton(onClick = { db.deleteExample(item.id); refresh() }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFE58A98)); Text("حذف", color = Color(0xFFE58A98), fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                    }
                    if (examples.isEmpty()) Text("لا توجد مقاطع موثّقة لهذه العبارة بعد. استخدم روابط البحث أعلاه، ثم أضف رابط المقطع الفعلي بعد التحقق منه.", color = Color(0xFF9AA6BB), fontSize = 13.sp, lineHeight = 20.sp)
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onSearchSources, modifier = Modifier.weight(1f)) { Text("ابحث عن مقطع", fontSize = 11.sp) }
                    Button(onClick = { showAdd = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6964F5))) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة مثال") }
                }
            }
        }
    }
    if (showAdd) AddPhraseExampleDialog(phraseId, phrase, onDismiss = { showAdd = false }, onSave = { example ->
        db.saveExample(example)
        refresh()
        showAdd = false
    })
    playing?.let { example -> PhraseExamplePlayerDialog(example, onDismiss = { playing = null }) }
    searchToOpen?.let { search -> PhraseExampleSearchDialog(search, onDismiss = { searchToOpen = null }) }
}

@Composable
private fun StatPill(label: String, value: Int, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF182438), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(vertical = 8.dp, horizontal = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), color = tint, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(label, color = Color(0xFF9AA6BB), fontSize = 9.sp)
        }
    }
}

@Composable
private fun ExampleCard(item: PhraseExample, number: Int, onPlay: () -> Unit, onDelete: () -> Unit) {
    Surface(Modifier.fillMaxWidth(), color = Color(0xFF182438), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل المثال", tint = Color(0xFF64D6A6)) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text("المثال $number • ${item.title}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("${item.sourceId} • ${matchLabel(item.matchType)}", color = Color(0xFF9AA6BB), fontSize = 10.sp)
                if (item.spokenText.isNotBlank()) Text(item.spokenText, color = Color(0xFFFFC56B), fontSize = 11.sp)
                Text(item.url, color = Color(0xFF8EA6D8), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (item.startMs > 0L) Text("بداية المقطع: ${item.startMs} ms", color = Color(0xFF9AA6BB), fontSize = 9.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف المثال", tint = Color(0xFFE58A98)) }
        }
    }
}

private fun matchLabel(type: String) = when (type) {
    PhraseExample.MATCH_EXACT -> "مطابقة حرفية"
    PhraseExample.MATCH_NATURAL -> "استخدام طبيعي"
    else -> "مطابقة سياقية"
}

@Composable
private fun AddPhraseExampleDialog(phraseId: String, phrase: String, onDismiss: () -> Unit, onSave: (PhraseExample) -> Unit) {
    var source by remember { mutableStateOf("playphrase") }
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var spoken by remember { mutableStateOf(phrase) }
    var match by remember { mutableStateOf(PhraseExample.MATCH_EXACT) }
    var start by remember { mutableStateOf("0") }
    var end by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مثال إلى قاعدة البيانات") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("معرّف العبارة: $phraseId", fontSize = 10.sp, color = Color.Gray)
                OutlinedTextField(source, { source = it }, label = { Text("معرّف المصدر (playphrase / yarn / غيره)") }, singleLine = true)
                OutlinedTextField(title, { title = it }, label = { Text("عنوان المقطع") }, singleLine = true)
                OutlinedTextField(url, { url = it }, label = { Text("رابط المقطع https://") }, singleLine = true)
                OutlinedTextField(spoken, { spoken = it }, label = { Text("النص المسموع في المقطع") })
                Text("نوع المطابقة", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(PhraseExample.MATCH_EXACT to "حرفية", PhraseExample.MATCH_NATURAL to "طبيعية", PhraseExample.MATCH_CONTEXT to "سياقية").forEach { (key, label) ->
                        FilterChip(selected = match == key, onClick = { match = key }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(start, { start = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("بداية ms") }, singleLine = true)
                    OutlinedTextField(end, { end = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("نهاية ms") }, singleLine = true)
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                Text("سيُحفظ المثال بحالة قيد المراجعة حتى تعتمد مطابقته.", color = Color.Gray, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            try {
                val s = start.toLongOrNull() ?: 0L
                val e = end.toLongOrNull() ?: 0L
                onSave(PhraseExample(phraseId = phraseId, sourceId = source.trim(), title = title.trim(), url = url.trim(), spokenText = spoken.trim(), startMs = s, endMs = e, matchType = match, verificationState = PhraseExample.STATE_PENDING))
            } catch (e: Exception) { error = e.message ?: "تحقق من البيانات والرابط" }
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun PhraseExampleSearchDialog(search: PhraseExampleSearch, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080D16)) {
            Column(Modifier.fillMaxSize().padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White) }
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                        Text("نتائج البحث عن العبارة", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${search.sourceName} • ${search.phraseText}", color = Color(0xFF9AA6BB), fontSize = 10.sp, maxLines = 2)
                    }
                }
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            setBackgroundColor(AndroidColor.BLACK)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            webChromeClient = WebChromeClient()
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    val phrase = JSONObject.quote(search.phraseText)
                                    view?.evaluateJavascript("""
                                        (function() {
                                          const phrase = $phrase;
                                          const visible = e => !!(e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length));
                                          const candidates = Array.from(document.querySelectorAll('input[type=search], input[placeholder*=search i], input[aria-label*=search i], input[type=text]'));
                                          const input = candidates.find(visible);
                                          if (!input || input.value === phrase) return;
                                          const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                                          if (setter) setter.call(input, phrase); else input.value = phrase;
                                          input.dispatchEvent(new Event('input', {bubbles:true}));
                                          input.dispatchEvent(new Event('change', {bubbles:true}));
                                        })();
                                    """.trimIndent(), null)
                                }
                            }
                            loadUrl(search.searchUrl)
                        }
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
                    update = { }
                )
                Text("حاول التطبيق تعبئة العبارة تلقائياً. اضغط بحث داخل الموقع إذا لم تظهر النتائج. لا تُحفظ النتيجة كمقطع موثّق إلا بعد التأكد من النطق والتوقيت والتشغيل.", color = Color(0xFF9AA6BB), fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
        }
    }
}

@Composable
private fun PhraseExamplePlayerDialog(example: PhraseExample, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080D16)) {
            Column(Modifier.fillMaxSize().padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = Color.White) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(example.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("تشغيل داخل التطبيق • ${example.sourceId}", color = Color(0xFF9AA6BB), fontSize = 10.sp)
                    }
                }
                AndroidView(
                    factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(AndroidColor.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                                val scheme = request?.url?.scheme?.lowercase()
                                return scheme != "https" && scheme != "http"
                            }
                        }
                        loadUrl(example.url)
                    }
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black),
                    update = { }
                )
                Text("إذا منع الموقع التضمين أو طلب تسجيل الدخول، فلن يتمكن المشغل من تجاوز قيوده.", color = Color(0xFF9AA6BB), fontSize = 10.sp, modifier = Modifier.padding(8.dp))
            }
        }
    }
}

@Composable
fun PhraseExamplesFeatureDialog(phraseId: String, phrase: String, onDismiss: () -> Unit) {
    var showSearch by remember(phraseId) { mutableStateOf(false) }
    PhraseExamplesDialog(
        phraseId = phraseId,
        phrase = phrase,
        onSearchSources = { showSearch = true },
        onDismiss = onDismiss
    )
    if (showSearch) PhraseSourcesDialog(phrase, onDismiss = { showSearch = false })
}

@Composable
fun PhraseExamplesInline(phraseId: String, phrase: String) {
    var show by remember(phraseId) { mutableStateOf(false) }
    OutlinedButton(
        onClick = { show = true },
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC56B))
    ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text("أمثلة العبارة من قاعدة البيانات")
    }
    if (show) PhraseExamplesFeatureDialog(phraseId, phrase) { show = false }
}
