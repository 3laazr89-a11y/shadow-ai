package com.example.shadowingai

import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

private data class PhraseSource(
    val id: String,
    val title: String,
    val subtitle: String,
    val kind: String,
    val description: String,
    val searchUrl: (String) -> String,
    val integrationNote: String
)

private val sourceCatalog = listOf(
    PhraseSource(
        id = "playphrase", title = "PlayPhrase.me", subtitle = "حوارات الأفلام والمسلسلات", kind = "بحث عبارة",
        description = "ابحث عن العبارة وشاهد المقاطع المتاحة من مشغّل المصدر نفسه داخل التطبيق.",
        searchUrl = { "https://www.playphrase.me/#/clip-search?language=en&q=${Uri.encode(it)}" },
        integrationNote = "الموقع هو الذي يتحكم في النتائج والتشغيل. لا نستخرج ملفات الفيديو ولا نعيد استضافتها."
    ),
    PhraseSource(
        id = "captionsearch", title = "Caption Search", subtitle = "بحث داخل كابشن فيديوهات حقيقية", kind = "بحث عبارة",
        description = "ابحث عن العبارة بين ترجمات فيديوهات حقيقية، ثم افتح النتائج عند توقيت النطق.",
        searchUrl = { "https://captionsearch.app/" },
        integrationNote = "النتائج روابط إلى فيديوهات يوتيوب الأصلية مع توقيتات؛ توفر التشغيل المضمن يعتمد على الفيديو وسياسات YouTube."
    ),
    PhraseSource(
        id = "captionsearchio", title = "CaptionSearch.io", subtitle = "بحث داخل قنوات يوتيوب مفهرسة", kind = "بحث داخل الموقع",
        description = "محرك مستقل يفهرس قنوات ومقاطع محددة ويتيح الانتقال إلى موضع العبارة في الفيديو.",
        searchUrl = { "https://captionsearch.io/" },
        integrationNote = "اكتب العبارة داخل الموقع واختر نتيجة ذات سياق حواري. فهرس الموقع محدود بالقنوات المفهرسة، ولا توجد واجهة API عامة موثقة أو ضمان للتضمين."
    ),
    PhraseSource(
        id = "yarn", title = "YARN", subtitle = "لقطات وحوارات من الأفلام والتلفزيون", kind = "بحث داخل الموقع",
        description = "افتح موقع YARN داخل نافذة التطبيق وابحث عن العبارة في حقل الموقع.",
        searchUrl = { "https://getyarn.io/" },
        integrationNote = "قد تتطلب بعض الميزات أو المقاطع تسجيل الدخول أو تكون غير متاحة للتضمين وفق إعدادات المصدر."
    ),
    PhraseSource(
        id = "ted", title = "TED Corpus Search Engine", subtitle = "نصوص المحاضرات والخطابات", kind = "بحث نصي",
        description = "ابحث داخل نصوص محاضرات TED عن التعبيرات والسياقات.",
        searchUrl = { "https://www.yohasebe.com/tcse/" },
        integrationNote = "يضم corpus آلاف محاضرات TED. نتائج البحث نصية مع موضع داخل المحاضرة؛ التشغيل يتم من مشغّل TCSE/المصدر، وليس عبر استخراج مقاطع مستقلة."
    )
)

@Composable
fun InlinePhraseSources(phrase: String) {
    var showSources by remember(phrase) { mutableStateOf(false) }
    OutlinedButton(
        onClick = { showSources = true },
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC56B))
    ) {
        Icon(Icons.Default.OpenInNew, contentDescription = null)
        Spacer(Modifier.width(7.dp))
        Text("البحث عن أمثلة حقيقية لهذه العبارة")
    }
    if (showSources) PhraseSourcesDialog(phrase) { showSources = false }
}

@Composable
fun PhraseSourcesDialog(phrase: String, onDismiss: () -> Unit) {
    var selectedId by remember(phrase) { mutableStateOf("playphrase") }
    var showRights by remember { mutableStateOf(false) }
    val selectedSource = sourceCatalog.first { it.id == selectedId }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF080D16)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("إغلاق")
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("مركز البحث عن المقاطع", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("المصادر تعمل داخل التطبيق", color = Color(0xFF8EDCC1), fontSize = 10.sp)
                    }
                }
                Surface(
                    color = Color(0xFF202B40),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 9.dp)
                ) {
                    Text(
                        phrase,
                        color = Color(0xFFFFC56B),
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.End,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(sourceCatalog, key = { it.id }) { source ->
                        FilterChip(
                            selected = selectedId == source.id,
                            onClick = { selectedId = source.id },
                            label = { Text(source.title, fontSize = 11.sp, maxLines = 1) }
                        )
                    }
                }
                Text(
                    selectedSource.subtitle,
                    color = Color(0xFFAAB5C9), fontSize = 11.sp,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth().padding(top = 5.dp)
                )
                Text(
                    selectedSource.integrationNote,
                    color = Color(0xFF9AA6BB), fontSize = 10.sp, lineHeight = 14.sp,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth().padding(top = 3.dp, bottom = 6.dp)
                )
                key(selectedSource.id, phrase) {
                    PhraseSourceWebView(
                        source = selectedSource,
                        phrase = phrase,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showRights = true }) {
                        Icon(Icons.Default.Policy, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("حقوق المحتوى")
                    }
                    Text("لا تنزيل ولا إعادة استضافة", color = Color(0xFF83D9B7), fontSize = 10.sp)
                }
            }
        }
    }
    if (showRights) RightsDialog(onDismiss = { showRights = false })
}

@Composable
private fun PhraseSourceWebView(source: PhraseSource, phrase: String, modifier: Modifier = Modifier) {
    var pageError by remember(source.id, phrase) { mutableStateOf("") }
    Box(
        modifier
            .background(Color(0xFF0C1422), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF303D54), RoundedCornerShape(12.dp))
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                FrameLayout(context).apply {
                    setBackgroundColor(AndroidColor.rgb(12, 20, 34))
                    val host = this
                    val web = WebView(context)
                    tag = web
                    web.setBackgroundColor(AndroidColor.rgb(12, 20, 34))
                    web.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        loadsImagesAutomatically = true
                        mediaPlaybackRequiresUserGesture = true
                        javaScriptCanOpenWindowsAutomatically = false
                        setSupportMultipleWindows(false)
                        allowFileAccess = false
                        allowContentAccess = false
                        setSupportZoom(true)
                        builtInZoomControls = true
                        displayZoomControls = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    }
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

                    var searchPrefillAttempted = false
                    web.webChromeClient = object : WebChromeClient() {
                        private var fullScreenView: View? = null
                        private var fullScreenCallback: WebChromeClient.CustomViewCallback? = null

                        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                            if (view == null || fullScreenView != null) {
                                callback?.onCustomViewHidden()
                                return
                            }
                            fullScreenView = view
                            fullScreenCallback = callback
                            host.removeView(web)
                            host.addView(view, FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            ))
                        }

                        override fun onHideCustomView() {
                            fullScreenView?.let { host.removeView(it) }
                            fullScreenView = null
                            fullScreenCallback?.onCustomViewHidden()
                            fullScreenCallback = null
                            if (web.parent == null) host.addView(web, FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            ))
                        }
                    }
                    web.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: android.webkit.WebResourceRequest?
                        ): Boolean {
                            val scheme = request?.url?.scheme?.lowercase() ?: return true
                            // Keep normal web navigation in this WebView; block intent/file/content schemes.
                            return scheme != "https" && scheme != "http"
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: android.webkit.WebResourceRequest?,
                            error: android.webkit.WebResourceError?
                        ) {
                            super.onReceivedError(view, request, error)
                            if (request?.isForMainFrame == true) {
                                pageError = "تعذر تحميل المصدر. تحقق من الاتصال أو جرّب مصدراً آخر."
                            }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            pageError = ""
                            if (!searchPrefillAttempted && source.id != "playphrase" && view != null) {
                                searchPrefillAttempted = true
                                view.evaluateJavascript(buildSearchPrefillScript(source.id, phrase), null)
                            }
                        }
                    }
                    addView(web, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ))
                    web.loadUrl(source.searchUrl(phrase))
                }
            },
            update = { host ->
                val web = host.tag as? WebView
                if (web != null && web.url.isNullOrBlank()) web.loadUrl(source.searchUrl(phrase))
            },
            onRelease = { host ->
                val webViews = (listOfNotNull(host.tag as? WebView) +
                    (0 until host.childCount).mapNotNull { host.getChildAt(it) as? WebView }).distinct()
                webViews.forEach { web ->
                    web.stopLoading()
                    web.webChromeClient = null
                    web.webViewClient = WebViewClient()
                    web.loadUrl("about:blank")
                    web.removeAllViews()
                    web.destroy()
                }
                host.removeAllViews()
            }
        )
        if (pageError.isNotBlank()) {
            Surface(
                modifier = Modifier.align(Alignment.Center).padding(16.dp),
                color = Color(0xFF202746), shape = RoundedCornerShape(12.dp)
            ) {
                Text(pageError, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.padding(14.dp))
            }
        }
    }
}

private fun buildSearchPrefillScript(sourceId: String, phrase: String): String {
    val safePhrase = JSONObject.quote(phrase)
    val selectors = when (sourceId) {
        "yarn" -> "input[type='search'], input[placeholder*='search' i], input[aria-label*='search' i]"
        "ted" -> "input[placeholder*='Search query' i], input[aria-label*='Search query' i], input[type='search']"
        "captionsearchio" -> "input[type='search'], input[placeholder*='search' i], input[aria-label*='search' i]"
        else -> "input[type='search'], input[placeholder*='search' i]"
    }
    return """
        (function() {
          const phrase = $safePhrase;
          const selectors = "$selectors";
          const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
          const input = Array.from(document.querySelectorAll(selectors)).find(visible);
          if (!input) return 'manual-search';
          const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
          if (setter && input instanceof HTMLInputElement) setter.call(input, phrase); else input.value = phrase;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          return 'prefilled';
        })();
    """.trimIndent()
}

@Composable
private fun RightsDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(color = Color(0xFF101827), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                Text("ميثاق حقوق المحتوى", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("نتعلم من المحتوى باحترام أصحابه.", color = Color(0xFFFFC56B), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                val rules = listOf(
                    "لا نستضيف أو ننسخ مقاطع لا نملك حقوقها.",
                    "لا نتجاوز تسجيل الدخول أو قيود الوصول أو التشغيل أو التضمين.",
                    "نحافظ على اسم المصدر ورابطه ولا ندّعي ملكية المحتوى.",
                    "لا نعرض ترخيصاً أو اسم صاحب حقوق إلا بمعلومة موثوقة.",
                    "ندعم ملفات المستخدم والمحتوى المرخص والمفتوح.",
                    "نحترم بلاغات أصحاب الحقوق وطلبات الإزالة."
                )
                rules.forEachIndexed { index, rule ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                        Text(rule, color = Color(0xFFD3DBE8), fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                        Text("${index + 1}.", color = Color(0xFF8F88FF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Text("إذا منع المصدر التضمين، نحترم هذا القيد ولا نحاول تجاوزه.", color = Color(0xFF9AA6BB), fontSize = 10.sp, textAlign = TextAlign.End, modifier = Modifier.padding(top = 8.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("حسناً") }
            }
        }
    }
}
