package com.example.shadowingai

import android.content.Context
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/** Unified local speech entry point. Pocket TTS and Supertonic 3 generate PCM directly. */
internal object TtsEngineManager {
    private const val PREFS = "shadow-ai"
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "Shadowing-TTS").apply { isDaemon = true } }
    private val generation = AtomicLong(0)

    fun speak(context: Context, text: String, speed: Float, accent: String, addToQueue: Boolean, status: (String) -> Unit) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val id = if (addToQueue) generation.get() else generation.incrementAndGet().also { stopEngines() }
        worker.execute {
            if (id != generation.get()) return@execute
            try {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                when (prefs.getString("tts_engine", "pocket") ?: "pocket") {
                    "supertonic" -> {
                        val speaker = prefs.getInt("supertonic_speaker", 6)
                        SupertonicTtsEngine.speak(context.applicationContext, clean, speed, speaker)
                        if (id == generation.get()) status("تم النطق باستخدام Supertonic 3 محلياً.")
                    }
                    else -> {
                        val voice = prefs.getString("pocket_voice", "alba") ?: "alba"
                        PocketTtsEngine.speak(context.applicationContext, clean, voice, speed)
                        if (id == generation.get()) status("تم النطق باستخدام Pocket TTS محلياً.")
                    }
                }
            } catch (e: Exception) {
                if (id == generation.get()) status("تعذر توليد الصوت: ${e.message ?: "خطأ غير معروف"}")
            }
        }
    }

    fun cleanupCache(context: Context) {
        context.cacheDir.listFiles()?.filter { it.name.startsWith("speech-") }?.forEach { it.delete() }
    }

    fun stop() { generation.incrementAndGet(); stopEngines() }
    private fun stopEngines() { PocketTtsEngine.stop(); SupertonicTtsEngine.stop() }
}
