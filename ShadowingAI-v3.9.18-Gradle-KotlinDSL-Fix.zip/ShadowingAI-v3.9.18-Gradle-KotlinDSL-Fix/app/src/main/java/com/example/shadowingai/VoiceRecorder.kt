package com.example.shadowingai

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import java.io.File

class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var activeFile: File? = null

    fun start(): File {
        stopPlayback()
        val file = File(context.filesDir, "shadow-${System.currentTimeMillis()}.m4a")
        activeFile = file
        val r = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128000)
            setAudioSamplingRate(44100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = r
        return file
    }

    fun stop(): File? {
        val r = recorder ?: return null
        val file = activeFile
        return try {
            r.stop()
            file?.takeIf { it.exists() && it.length() > 0L }
        } catch (_: Exception) { null }
        finally { try { r.reset(); r.release() } catch (_: Exception) {}; recorder = null; activeFile = null }
    }

    fun play(path: String, onDone: () -> Unit = {}) {
        stopPlayback()
        player = MediaPlayer().apply {
            setDataSource(path)
            setOnCompletionListener { it.release(); player = null; onDone() }
            setOnErrorListener { mp, _, _ -> mp.release(); player = null; onDone(); true }
            prepare()
            start()
        }
    }

    fun stopPlayback() { try { player?.stop() } catch (_: Exception) {}; try { player?.release() } catch (_: Exception) {}; player = null }
    fun release() { try { recorder?.stop() } catch (_: Exception) {}; try { recorder?.release() } catch (_: Exception) {}; recorder = null; stopPlayback() }
}
