package com.example.shadowingai

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.google.mediapipe.tasks.audio.texttospeech.SynthesisOptions
import com.google.mediapipe.tasks.audio.texttospeech.TextToSpeech
import com.google.mediapipe.tasks.audio.texttospeech.TextToSpeechOptions
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/** Offline PocketTTS runtime using Google's official MediaPipe Tasks Audio API. */
internal object PocketTtsEngine {
    const val MODEL_FILE = "pocket_tts_en_int8.litertlm"
    const val MODEL_URL = "https://huggingface.co/litert-community/pocket-tts/resolve/main/$MODEL_FILE"
    private const val MIN_MODEL_BYTES = 100L * 1024L * 1024L
    private val lock = Any()
    @Volatile private var engine: TextToSpeech? = null
    @Volatile private var activeTrack: AudioTrack? = null
    private val cancelled = AtomicBoolean(false)

    fun modelFile(context: Context): File = File(context.filesDir, MODEL_FILE)
    fun isModelReady(context: Context): Boolean = modelFile(context).let { it.isFile && it.length() >= MIN_MODEL_BYTES }

    fun downloadModel(context: Context, progress: (Int) -> Unit) {
        if (isModelReady(context)) { progress(100); return }
        val target = modelFile(context)
        val partial = File(context.filesDir, "$MODEL_FILE.part")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30000
                readTimeout = 120000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "ShadowingAI-Android/3.9.14")
            }
            val code = connection.responseCode
            check(code == HttpURLConnection.HTTP_OK) { "تعذر تنزيل نموذج Pocket TTS (HTTP $code). تحقق من الاتصال ثم أعد المحاولة." }
            val total = connection.contentLengthLong
            var receivedTotal = 0L
            connection.inputStream.use { input ->
                partial.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var count: Int
                    var received = 0L
                    var lastPercent = -1
                    while (input.read(buffer).also { count = it } != -1) {
                        output.write(buffer, 0, count)
                        received += count
                        receivedTotal += count
                        if (total > 0L) {
                            val percent = ((received * 100L) / total).toInt().coerceIn(0, 100)
                            if (percent != lastPercent) { lastPercent = percent; progress(percent) }
                        }
                    }
                }
            }
            if (total > 0L) check(receivedTotal == total) { "انقطع تنزيل النموذج قبل اكتماله ($receivedTotal من $total بايت). أعد المحاولة." }
            check(partial.length() >= MIN_MODEL_BYTES) { "ملف النموذج غير مكتمل (${partial.length()} بايت). احذف التنزيل وأعد المحاولة." }
            if (target.exists()) target.delete()
            check(partial.renameTo(target)) { "اكتمل التنزيل لكن تعذر تثبيت ملف النموذج." }
            progress(100)
        } catch (e: Exception) {
            partial.delete()
            throw e
        } finally { connection?.disconnect() }
    }

    private fun getEngine(context: Context, voice: String): TextToSpeech {
        synchronized(lock) {
            engine?.let { return it }
            val model = modelFile(context)
            check(isModelReady(context)) { "نزّل نموذج Pocket TTS أولاً من إعدادات الصوت (حوالي 163 MB)." }
            val base = BaseOptions.builder()
                .setModelAssetPath(model.absolutePath)
                .setDelegate(Delegate.CPU)
                .build()
            val options = TextToSpeechOptions(
                baseOptions = base,
                defaultVoiceId = voice,
                defaultLocale = "en-US",
                speakingRate = 1.0f,
                targetBucket = 0,
                cacheDirectory = File(context.cacheDir, "pocket-tts-cache").absolutePath
            )
            return TextToSpeech.create(options).also { engine = it }
        }
    }

    fun speak(context: Context, text: String, voice: String, speed: Float) {
        cancelled.set(false)
        val tts = getEngine(context.applicationContext, voice)
        val result = tts.synthesize(text, SynthesisOptions(voiceId = voice, locale = null))
        if (cancelled.get()) return
        val samples = result.samples
        require(samples.isNotEmpty()) { "Pocket TTS لم ينتج عينات صوتية." }
        val shorts = ShortArray(samples.size) { index ->
            (samples[index].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        val sampleRate = result.sampleRateHz
        val minBytes = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minBytes > 0) { "تعذر تهيئة مخرج الصوت على هذا الجهاز." }
        val track = AudioTrack(
            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBytes, 8192),
            AudioTrack.MODE_STREAM
        )
        activeTrack = track
        try {
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                track.playbackParams = track.playbackParams.setSpeed(speed.coerceIn(0.65f, 1.35f))
            }
            track.play()
            var offset = 0
            while (offset < shorts.size && !cancelled.get()) {
                val written = track.write(shorts, offset, minOf(4096, shorts.size - offset), AudioTrack.WRITE_BLOCKING)
                if (written < 0) error("فشل إرسال الصوت إلى مخرج Android ($written).")
                if (written == 0) break
                offset += written
            }
            if (!cancelled.get()) {
                // Drain the final PCM frames before releasing the output device.
                while (track.playbackHeadPosition.toLong() < shorts.size.toLong() && !cancelled.get()) Thread.sleep(12)
            }
        } finally {
            try { track.pause(); track.flush(); track.release() } catch (_: Exception) { }
            if (activeTrack === track) activeTrack = null
        }
    }

    fun stop() {
        cancelled.set(true)
        try { activeTrack?.let { it.pause(); it.flush(); it.stop() } } catch (_: Exception) { }
        try { engine?.cancel() } catch (_: Exception) { }
    }

    fun close() {
        stop()
        synchronized(lock) {
            try { engine?.close() } catch (_: Exception) { }
            engine = null
        }
    }
}
