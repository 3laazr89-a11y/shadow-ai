package com.example.shadowingai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import android.media.MediaPlayer
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF182438)
private val Purple = Color(0xFF6964F5)
private val Cyan = Color(0xFF00B6D0)
private val Muted = Color(0xFF9AA6BB)
private val storeExecutor = Executors.newSingleThreadExecutor()
private val aiExecutor = Executors.newSingleThreadExecutor()

private data class Phrase(
    val id: String, val english: String, val ipa: String, val arabic: String,
    val level: String, val category: String, val tip: String,
    val favorite: Boolean = false, val mastered: Boolean = false,
    val practiceCount: Int = 0, val recordingPath: String = "", val custom: Boolean = false
)

private val seedPhrases = listOf(
    Phrase("p1", "I was just wondering if you might have a couple of minutes to talk.", "/aɪ wəz dʒʌst ˈwʌndərɪŋ ɪf juː maɪt hæv ə ˈkʌpl əv ˈmɪnɪts tə tɔːk/", "كنت أتساءل فقط عما إذا كان لديك بضع دقائق للحديث.", "متوسط", "محادثات يومية", "في just wondering، خفّف /t/ في just قبل /w/؛ في الكلام السريع قد يضعف أو يسقط، فتُسمع تقريبًا /dʒʌs ˈwʌndərɪŋ/. صِل الكلمتين من دون وقفة، ثم أكمل if بنبرة غير نهائية."),
    Phrase("p2", "Could you give me a hand with this?", "/kʊdʒuː ɡɪv miː ə hænd wɪð ðɪs/", "هل يمكنك مساعدتي في هذا؟", "مبتدئ", "محادثات يومية", "في Could you، قد يندمج /d/ مع /j/ في you لتُسمع /kʊdʒu/ (قريبة من couldja). انطقها كوحدة واحدة، ثم شدّد على hand واترك a خفيفة /ə/."),
    Phrase("p3", "That sounds like a great idea.", "/ðæt saʊndz laɪk ə ɡreɪt aɪˈdɪə/", "تبدو هذه فكرة رائعة.", "مبتدئ", "محادثات يومية", "خفّف a إلى /ə/ وصِل like a لتُسمع تقريبًا /laɪkə/ من دون وقفة. اجعل النبر الأوضح على great، ثم ارفع نبرة idea قليلًا في نهاية الجملة."),
    Phrase("p4", "I really appreciate you taking the time.", "/aɪ ˈrɪəli əˈpriːʃieɪt juː/", "أقدّر حقًا تخصيصك الوقت.", "متوسط", "العمل", "في appreciate you، شدّد على مقطع /ˈpriːʃi/ وخفّف you إلى /jə/ في الكلام المتصل. قد يندمج /t/ مع /j/ باتجاه /tʃ/ لدى بعض المتحدثين الأمريكيين؛ لا تبالغ في هذا الدمج."),
    Phrase("p5", "Would you mind if we rescheduled for tomorrow?", "/wʊdʒuː maɪnd ɪf wiː ˌriːˈskedʒuːld/", "هل تمانع لو أعدنا الموعد إلى الغد؟", "متقدم", "العمل", "في Would you، قد يندمج /d/ مع بداية you /j/ ليُسمع /wʊdʒu/ (قريبة من wouldja). صِلها بسلاسة، مع إبقاء mind واضحًا."),
    Phrase("p6", "Let me get back to you on that.", "/let miː ɡet bæk tə juː/", "دعني أعود إليك بخصوص ذلك.", "متوسط", "العمل", "في الكلام السريع قد تُختصر let me إلى /lɛmi/. وفي get back، اجعل /t/ قصيرة وغير منفجرة قبل /b/، ثم اخفض النبرة عند that لتبدو واثقًا."),
    Phrase("p7", "Could I get a window seat, please?", "/kʊd aɪ ɡet ə ˈwɪndoʊ siːt pliːz/", "هل يمكنني الحصول على مقعد بجانب النافذة، من فضلك؟", "مبتدئ", "السفر", "اربط get a مباشرة؛ في لهجات أمريكية قد يتحول /t/ بين حركتين إلى رفرفة خفيفة، فتُسمع تقريبًا /ˈwɪndoʊ siːt/ بعد /ɡɛɾə/. هذا شكل لهجي وليس نطقًا إلزاميًا؛ أبرز please بلطف."),
    Phrase("p8", "I appreciate your flexibility.", "/aɪ əˈpriːʃieɪt jʊr ˌfleksəˈbɪləti/", "أقدّر مرونتك.", "متقدم", "العمل", "في flexibility، اجعل النبر على /ˌfleks/ ثم خفّف المقاطع اللاحقة؛ لا تمنح كل مقطع القوة نفسها. صِل your بـ flexibility من دون وقفة."),
    Phrase("p9", "To be honest, I haven't thought about it that way.", "/tə bi ˈɑːnɪst aɪ ˈhævənt θɔːt əˈbaʊt ɪt/", "بصراحة، لم أفكر في الأمر بهذه الطريقة.", "متوسط", "روابط الطلاقة", "في about it، صِل /t/ الأخيرة مباشرة بحركة it فتُسمع تقريبًا /əˈbaʊtɪt/. خفّف to إلى /tə/، وقل العبارة في مجموعات قصيرة بلا توقف بين about وit."),
    Phrase("p10", "Where is the nearest train station?", "/wer ɪz ðə ˈnɪrəst treɪn ˈsteɪʃən/", "أين أقرب محطة قطار؟", "مبتدئ", "السفر", "في Where is، صِل /r/ الأخيرة في where بحركة is لتسمعها متصلة /werɪz/، وخفّف the إلى /ðə/. ارفع نبرة السؤال قليلًا في النهاية."),
    Phrase("p11", "Let's play it by ear and see how things turn out.", "/lets pleɪ ɪt baɪ ɪr/", "لنتصرف بعفوية ونرَ كيف ستسير الأمور.", "متقدم", "تعابير", "صِل play it مباشرة عبر الحركتين /eɪ.ɪ/ من دون وقفة، ثم اربط by ear بسلاسة. التعبير يعني التصرف وفق الظروف دون خطة ثابتة."),
    Phrase("p12", "I will keep you posted.", "/aɪ wɪl kiːp juː ˈpoʊstɪd/", "سأبقيك على اطلاع.", "متوسط", "العمل", "في keep you، أبقِ إغلاق /p/ واضحًا ثم انتقل مباشرة إلى /j/ في you، كأنها كتلة واحدة /kiːpjuː/ من دون فجوة. شدّد على posted."),
)

private fun importedPhrases(context: android.content.Context): List<Phrase> = try {
    val data = context.assets.open("phrases_enriched.json").bufferedReader().use { JSONArray(it.readText()) }
    (0 until data.length()).mapNotNull { index ->
            val item = data.getJSONObject(index)
            val text = item.optString("english").trim()
            if (text.isBlank() || seedPhrases.any { it.english.equals(text, ignoreCase = true) }) return@mapNotNull null
            val wordCount = text.split(Regex("\\s+")).size
            val clauseMarkers = listOf(" if ", " although ", " unless ", " whenever ", " as long as ", " no matter ", " I wouldn't ", " I don't think ")
            val intermediate = wordCount > 4 || clauseMarkers.any { text.contains(it, ignoreCase = true) } || text.contains("...")
            val category = when {
                listOf("airport", "train", "flight", "travel", "ticket", "station", "seat", "direction", "lost").any { text.contains(it, true) } -> "السفر"
                listOf("work", "meeting", "job", "office", "deadline", "project", "business").any { text.contains(it, true) } -> "العمل"
                listOf("friend", "love", "miss you", "hang out", "dinner", "lunch", "coffee").any { text.contains(it, true) } -> "اجتماعي"
                listOf("by ear", "you live and learn", "at the end of the day", "the whole point", "once in a while", "break a").any { text.contains(it, true) } -> "تعابير وروابط"
                else -> "محادثات يومية"
            }
            Phrase(item.optString("id", "import-${index + 1}"), text, item.optString("ipa"), item.optString("arabic"), if (intermediate) "متوسط" else "مبتدئ", category, item.optString("tip"))
        }
} catch (_: Exception) { emptyList() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep the existing local phrase/example database and search index intact.
        val examplesDb = PhraseExamplesDatabase.getInstance(applicationContext)
        examplesDb.writableDatabase
        storeExecutor.execute {
            val phraseSearchCatalog = (seedPhrases + importedPhrases(applicationContext)).map { it.id to it.english }
            examplesDb.seedPhraseSearches(phraseSearchCatalog)
        }
        val appContext = applicationContext
        TtsEngineManager.cleanupCache(appContext)
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        setContent {
            ShadowingRoot(onSpeak = { text, rate, accent, addToQueue ->
                TtsEngineManager.speak(appContext, text, rate, accent, addToQueue) { message ->
                    mainHandler.post { Toast.makeText(appContext, message, Toast.LENGTH_LONG).show() }
                }
            })
        }
    }

    override fun onDestroy() {
        TtsEngineManager.stop()
        super.onDestroy()
    }
}

@Composable
private fun ShadowingRoot(onSpeak: (String, Float, String, Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("shadow-ai", 0).also { it.edit().remove("youtube_api_key").apply() } }
    var realExamplesPhrase by remember { mutableStateOf<Phrase?>(null) }
    var selectedCaption by remember { mutableStateOf<CaptionSegment?>(null) }
    var tab by remember { mutableStateOf("المكتبة") }
    var pendingSubtitleUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCaptionCategory by remember { mutableStateOf("أفلام ومسلسلات") }
    var captionImportMessage by remember { mutableStateOf("") }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { mediaUri ->
        val subtitleUri = pendingSubtitleUri
        if (mediaUri != null && subtitleUri != null) {
            try { context.contentResolver.takePersistableUriPermission(mediaUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            try { context.contentResolver.takePersistableUriPermission(subtitleUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            captionImportMessage = "جارٍ استيراد الكابشن وفهرسة التوقيتات..."
            val selectedCategory = pendingCaptionCategory
            storeExecutor.execute {
                try {
                    val count = CaptionImporter.importCaptions(context, subtitleUri, mediaUri, selectedCategory)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        captionImportMessage = "تمت فهرسة $count مقطعاً. يمكنك الآن البحث في كلام هذا المصدر."
                        tab = "الكابشن"
                    }
                } catch (e: Exception) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        captionImportMessage = e.message ?: "تعذر استيراد ملف الكابشن."
                        tab = "الكابشن"
                    }
                }
            }
        } else if (subtitleUri != null) {
            captionImportMessage = "لم يتم اختيار ملف فيديو أو صوت؛ لم يُضف المصدر إلى الفهرس."
        }
        pendingSubtitleUri = null
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { subtitleUri ->
        if (subtitleUri != null) {
            pendingSubtitleUri = subtitleUri
            captionImportMessage = "اختر الآن ملف الفيديو أو الصوت المرتبط بهذه الترجمة."
            mediaPicker.launch(arrayOf("video/*", "audio/*"))
        }
    }
    fun openRealExamples(phrase: Phrase) { realExamplesPhrase = phrase }
    val items: SnapshotStateList<Phrase> = remember { mutableStateListOf<Phrase>().apply { addAll(readPhrases(prefs, context)) } }
    var query by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("الكل") }
    var category by remember { mutableStateOf("الكل") }
    var rate by remember { mutableFloatStateOf(prefs.getFloat("rate", 1f)) }
    var accent by remember { mutableStateOf(prefs.getString("accent", "en-US") ?: "en-US") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "") ?: "") }
    var activeId by remember { mutableStateOf(items.firstOrNull()?.id ?: "p1") }
    var isRecording by remember { mutableStateOf(false) }
    var recordingPath by remember { mutableStateOf(items.firstOrNull { it.id == activeId }?.recordingPath.orEmpty()) }
    var transcript by remember { mutableStateOf("") }
    var coachText by remember { mutableStateOf("") }
    var score by remember { mutableIntStateOf(-1) }
    var focusWords by remember { mutableStateOf(emptyList<String>()) }
    var nextStep by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var generatingPhrases by remember { mutableStateOf(false) }
    var generationMessage by remember { mutableStateOf("") }
    var naturalSpeechBusy by remember { mutableStateOf(false) }
    var naturalPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) {
        onDispose { naturalPlayer?.release(); naturalPlayer = null }
    }
    var naturalSpeechMessage by remember { mutableStateOf("") }
    var loopCount by remember { mutableIntStateOf(0) }
    var pendingTranscription by remember { mutableStateOf(false) }
    var visiblePhraseLimit by remember { mutableIntStateOf(36) }
    val recorder = remember { VoiceRecorder(context) }
    DisposableEffect(recorder) { onDispose { recorder.release() } }
    LaunchedEffect(query, category, level) { visiblePhraseLimit = 36 }
    val active = items.firstOrNull { it.id == activeId } ?: items.firstOrNull() ?: seedPhrases.first()

    fun persist() { prefs.edit().putString("phrases", writePhrases(items)).apply() }
    fun generatePhrases(category: String, selectedLevel: String, topic: String) {
        if (generatingPhrases) return
        if (endpoint.isBlank()) {
            generationMessage = "أدخل عنوان خادم AI في صفحة التقدم والإعدادات أولاً."
            return
        }
        generatingPhrases = true
        generationMessage = "يتصل بالنموذج المفتوح ويولّد عبارات أصلية..."
        val configuredEndpoint = endpoint.trim()
        aiExecutor.execute {
            try {
                val generated = PhraseGenerator.generate(configuredEndpoint, category, selectedLevel, topic, 5)
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    val existing = items.map { it.english.trim().lowercase() }.toHashSet()
                    val additions = generated.filterNot { existing.contains(it.english.trim().lowercase()) }.mapIndexed { index, phrase ->
                        Phrase(
                            id = "ai-${System.currentTimeMillis()}-$index",
                            english = phrase.english, ipa = phrase.ipa, arabic = phrase.arabic,
                            level = selectedLevel, category = category, tip = phrase.tip, custom = true
                        )
                    }
                    if (additions.isNotEmpty()) {
                        items.addAll(0, additions)
                        persist()
                        storeExecutor.execute {
                            PhraseExamplesDatabase.getInstance(context).seedPhraseSearches(additions.map { it.id to it.english })
                        }
                        activeId = additions.first().id
                        query = ""
                        tab = "المكتبة"
                        generationMessage = "تم إنشاء ${additions.size} عبارات جديدة وحفظها في مكتبتك. ابحث عن أمثلة فيديو لكل عبارة بشكل مستقل."
                    } else generationMessage = "العبارات الناتجة موجودة مسبقاً في مكتبتك؛ لم تتم إضافة نسخ مكررة."
                    generatingPhrases = false
                }
            } catch (error: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    generationMessage = error.message ?: "تعذر الاتصال بخدمة توليد العبارات."
                    generatingPhrases = false
                }
            }
        }
    }
    fun analyze(text: String) {
        transcript = text; busy = true; score = -1; focusWords = emptyList(); nextStep = ""; coachText = "جارٍ إعداد الملاحظات..."
        val expected = active.english
        val ipa = active.ipa
        val tip = active.tip
        val selectedAccent = accent
        val aiEndpoint = endpoint.trim()
        storeExecutor.execute {
            val result = CoachService.analyze(aiEndpoint, expected, text, ipa, tip, selectedAccent)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                score = result.score
                val comparisons = buildList {
                    if (result.missingWords.isNotEmpty()) add("غير ظاهرة: ${result.missingWords.joinToString(", ")}")
                    if (result.substitutions.isNotEmpty()) add("محتمل أنها استُبدلت: ${result.substitutions.joinToString("، ")}")
                    if (result.extraWords.isNotEmpty()) add("زائدة: ${result.extraWords.joinToString(", ")}")
                }.joinToString("؛ ")
                coachText = (if (result.viaAi) "إرشاد AI للنص: " else "مقارنة التفريغ: ") + result.feedback +
                    if (comparisons.isNotBlank()) "\nتفاصيل المطابقة: $comparisons." else ""
                focusWords = result.focusWords
                nextStep = result.nextStep
                busy = false
                val index = items.indexOfFirst { it.id == activeId }
                if (index >= 0) { items[index] = items[index].copy(practiceCount = items[index].practiceCount + 1); persist() }
            }
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val words = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (result.resultCode == android.app.Activity.RESULT_OK && words.isNotBlank()) analyze(words)
        else { coachText = "لم يصل تفريغ واضح. أعد المحاولة وتحدث بوضوح."; busy = false }
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            pendingTranscription = false
            coachText = "يلزم السماح بإذن الميكروفون للتسجيل أو التقييم الصوتي."
        } else if (pendingTranscription) {
            pendingTranscription = false
            try { speechLauncher.launch(speechIntent(accent)) } catch (_: Exception) { coachText = "تعذر فتح خدمة التعرف على الكلام." }
        } else if (granted && !isRecording) try {
            val file = recorder.start(); recordingPath = file.absolutePath; isRecording = true; coachText = "يتم تسجيل صوتك محليًا على الجهاز..."
        } catch (_: Exception) { coachText = "تعذر بدء التسجيل. تحقق من إذن الميكروفون." }
    }
    fun startTranscription() {
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(context)) { coachText = "خدمة تحويل الكلام إلى نص غير متاحة على هذا الجهاز."; return }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingTranscription = true
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        try { speechLauncher.launch(speechIntent(accent)) } catch (_: Exception) { coachText = "تعذر فتح خدمة التعرف على الكلام." }
    }
    fun finishRecording() {
        val saved = recorder.stop()
        isRecording = false
        if (saved != null) {
            recordingPath = saved.absolutePath
            val index = items.indexOfFirst { it.id == activeId }
            if (index >= 0) { items[index] = items[index].copy(recordingPath = saved.absolutePath); persist() }
            coachText = "تم حفظ التسجيل على الجهاز. شغّله للمقارنة أو اطلب تقييم التفريغ الصوتي."
        } else coachText = "تعذر حفظ التسجيل؛ حاول تسجيل مقطع أطول."
    }

    LaunchedEffect(activeId) { recordingPath = items.firstOrNull { it.id == activeId }?.recordingPath.orEmpty(); transcript = ""; score = -1 }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF101827)).padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SmallBadge("🔥 ${items.sumOf { it.practiceCount }} تدريب", Color(0xFFFFB13B))
                SmallBadge("✓ ${items.count { it.mastered }} متقنة", Color(0xFF23C99A))
                SmallBadge("✦ مدرب AI", Purple)
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    "المكتبة" -> {
                        Text("مكتبة العبارات والتظليل", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                        Text("استمع، سجّل، وتمرّن مع مدربك الذكي", color = Muted, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 14.dp))
                        SearchBox(query, { query = it })
                        Spacer(Modifier.height(10.dp))
                        Text("سرعة الصوت", color = Muted, fontSize = 13.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState())) { listOf(.75f to "0.75× بطيء", 1f to "1× طبيعي", 1.25f to "1.25× سريع").forEach { (v, label) -> Pill(label, rate == v) { rate = v; prefs.edit().putFloat("rate", v).apply() } } }
                        Row(Modifier.horizontalScroll(rememberScrollState())) { (listOf("الكل") + items.map { it.category }.distinct()).forEach { c -> Pill(c, category == c) { category = c } } }
                        Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("الكل", "مبتدئ", "متوسط", "متقدم", "★ المفضلة").forEach { l -> Pill(l, level == l) { level = l } } }
                        val shown = items.filter { (it.english + " " + it.arabic).contains(query, true) && (category == "الكل" || it.category == category) && (level == "الكل" || level == "★ المفضلة" && it.favorite || it.level == level) }
                        shown.take(visiblePhraseLimit).forEach { phrase -> PhraseCard(phrase, onSpeak = { onSpeak(phrase.english, rate, accent, false) }, onRealExamples = { openRealExamples(phrase) }, onSelect = { activeId = phrase.id; tab = "الاستوديو"; coachText = ""; score = -1 }, onFavorite = { val i = items.indexOfFirst { it.id == phrase.id }; if (i >= 0) items[i] = items[i].copy(favorite = !items[i].favorite); persist() }, onMaster = { val i = items.indexOfFirst { it.id == phrase.id }; if (i >= 0) items[i] = items[i].copy(mastered = !items[i].mastered); persist() }, onDelete = { items.removeAll { it.id == phrase.id }; persist() }) }
                        if (shown.size > visiblePhraseLimit) TextButton(onClick = { visiblePhraseLimit += 36 }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("عرض المزيد (${shown.size - visiblePhraseLimit} متبقية)", color = Color(0xFFA49BFF)) }
                        if (shown.isEmpty()) EmptyText("لا توجد عبارات مطابقة")
                    }
                    "الاستوديو" -> StudioScreen(active, rate, isRecording, recordingPath, transcript, coachText, score, busy,
                        onSpeak = { onSpeak(active.english, rate, accent, false) },
                        onGenerateNatural = { onSpeak(active.english, rate, accent, false) }, naturalSpeechBusy = false, naturalSpeechMessage = "يُستخدم محرك النطق المحلي المحدد في التطبيق." ,
                        onSpeakSlow = { onSpeak(active.english, minOf(rate, .75f), accent, false) },
                        onSpeakChunk = { chunk -> onSpeak(chunk, rate, accent, false) },
                        onSpeakWord = { word -> onSpeak(word, rate, accent, false) },
                        onRecord = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            if (!isRecording) try { recordingPath = recorder.start().absolutePath; isRecording = true; coachText = "يتم التسجيل..." } catch (_: Exception) { coachText = "تعذر بدء التسجيل." }
                        } else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                        onStop = { finishRecording() },
                        onPlay = { if (recordingPath.isNotBlank()) try { recorder.play(recordingPath) { } } catch (_: Exception) { coachText = "تعذر تشغيل التسجيل." } else coachText = "سجّل صوتك أولًا." },
                        onTranscribe = { startTranscription() }, onLoop = { loopCount = 5; repeat(5) { i -> onSpeak(active.english, rate, accent, i > 0) } }, loopCount = loopCount, focusWords = focusWords, nextStep = nextStep)
                    "إضافة" -> AddPhraseScreen(
                        onAdd = { en, ar, ipa, cat, lvl, tip ->
                            if (en.isNotBlank() && ar.isNotBlank()) { val p = Phrase("u-${System.currentTimeMillis()}", en.trim(), ipa.trim(), ar.trim(), lvl, cat, tip.trim(), custom = true); items.add(0, p); persist(); activeId = p.id; tab = "المكتبة" }
                        },
                        onGenerate = { cat, lvl, topic -> generatePhrases(cat, lvl, topic) },
                        generating = generatingPhrases,
                        generationMessage = generationMessage
                    )
                    "الكابشن" -> CaptionSearchScreen(
                        onImport = { category -> pendingCaptionCategory = category; subtitlePicker.launch(arrayOf("*/*")) },
                        importMessage = captionImportMessage,
                        onPlay = { selectedCaption = it }
                    )
                    else -> ProgressScreen(items.size, items.count { it.favorite }, items.count { it.mastered }, items.sumOf { it.practiceCount }, rate, accent, endpoint,
                        onRate = { rate = it; prefs.edit().putFloat("rate", it).apply() }, onAccent = { accent = it; prefs.edit().putString("accent", it).apply() }, onEndpoint = { endpoint = it; prefs.edit().putString("endpoint", it).apply() })
                }
            }
            NavigationBar(containerColor = Color(0xFF151D2D)) {
                listOf("التقدم", "إضافة", "الكابشن", "الاستوديو", "المكتبة").forEach { label -> NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Text(when(label) { "التقدم" -> "▥"; "إضافة" -> "+"; "الكابشن" -> "⌕"; "الاستوديو" -> "⇄"; else -> "▤" }, fontSize = 20.sp) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFF9D96FF), selectedTextColor = Color(0xFF9D96FF), indicatorColor = Color(0xFF29284D), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
            }
        }
        realExamplesPhrase?.let { phrase -> PhraseExamplesFeatureDialog(phrase.id, phrase.english, onDismiss = { realExamplesPhrase = null }) }
        selectedCaption?.let { segment -> CaptionPlayerDialog(segment, onDismiss = { selectedCaption = null }) }
    }
}

@Composable private fun SearchBox(value: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("⌕", color = Muted, fontSize = 23.sp); Spacer(Modifier.width(8.dp))
        BasicTextField(value, onChange, Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp, textAlign = TextAlign.End), decorationBox = { inner -> if (value.isEmpty()) Text("ابحث بالإنجليزية أو العربية...", color = Muted, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()); inner() })
    }
}

@Composable private fun PhraseCard(p: Phrase, onSpeak: () -> Unit, onRealExamples: () -> Unit, onSelect: () -> Unit, onFavorite: () -> Unit, onMaster: () -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp).background(Panel, RoundedCornerShape(17.dp)).padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(if (p.favorite) "♥" else "♡", color = Color(0xFFFC7390), modifier = Modifier.padding(end = 10.dp)); if (p.custom) TextButton(onClick = onDelete) { Text("حذف", color = Muted) } }
            Text("${p.level} • ${p.category}${if (p.mastered) " • ✓ متقنة" else ""}", color = Muted, fontSize = 11.sp)
        }
        Text(p.english, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, lineHeight = 27.sp)
        if (p.ipa.isNotBlank()) Text(p.ipa, color = Color(0xFFA49BFF), fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        if (p.arabic.isNotBlank()) Text(p.arabic, color = Color(0xFFD8DFEB), fontSize = 15.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        else Text("الترجمة العربية غير متوفرة في الملف المرفق", color = Muted, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 5.dp))
        if (p.tip.isNotBlank()) PronunciationTip(p.tip, Modifier.padding(top = 8.dp))
        Text("تدرّبت عليها ${p.practiceCount} مرة", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.End).padding(top = 5.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedButton(onClick = onSpeak, modifier = Modifier.weight(1f)) { Text("◖ استمع", color = Cyan) }
            OutlinedButton(onClick = onRealExamples, modifier = Modifier.weight(1.25f)) { Text("قاعدة أمثلة العبارة", color = Color(0xFFFFC56B)) }
        }
        Button(onClick = onSelect, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("استوديو التظليل") }
        Row(Modifier.align(Alignment.End)) { TextButton(onClick = onFavorite) { Text(if (p.favorite) "إزالة من المفضلة" else "أضف للمفضلة", color = Color(0xFFF28BA2), fontSize = 11.sp) }; TextButton(onClick = onMaster) { Text(if (p.mastered) "إلغاء الإتقان" else "علّمها متقنة", color = Muted, fontSize = 11.sp) } }
    }
}

@Composable private fun StudioScreen(p: Phrase, rate: Float, recording: Boolean, path: String, transcript: String, feedback: String, score: Int, busy: Boolean, onSpeak: () -> Unit, onGenerateNatural: () -> Unit, naturalSpeechBusy: Boolean, naturalSpeechMessage: String, onSpeakSlow: () -> Unit, onSpeakChunk: (String) -> Unit, onSpeakWord: (String) -> Unit, onRecord: () -> Unit, onStop: () -> Unit, onPlay: () -> Unit, onTranscribe: () -> Unit, onLoop: () -> Unit, loopCount: Int, focusWords: List<String>, nextStep: String) {
    var showRealExamples by remember(p.id) { mutableStateOf(false) }
    Text("استوديو التظليل", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
    Text("${p.level} • ${p.category}", color = Muted, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    Spacer(Modifier.height(16.dp)); Text(p.english, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
    Text(p.ipa, color = Color(0xFFA49BFF), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)); Text(p.arabic, color = Color(0xFFD9E0EA), fontSize = 16.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.End)
    Spacer(Modifier.height(16.dp))
    Text("دليل اللفظ خطوة بخطوة", color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold, fontSize = 17.sp)
    Text("١) استمع مرة ببطء ولاحظ النبر في IPA. ٢) كرر كل مقطع وحده. ٣) صِل المقاطع دون إدخال وقفات بين الكلمات الخفيفة. ٤) قل العبارة كاملة بإيقاع طبيعي.", color = Muted, fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onSpeakSlow, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) { Text("استمع ببطء • 0.75×") }
        OutlinedButton(onClick = onSpeak) { Text("السرعة المختارة • ${rate}×") }
    }
    Button(
        onClick = onGenerateNatural,
        enabled = !naturalSpeechBusy,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B876F)),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    ) { Text("✦ استمع إلى العبارة بالصوت المختار") }
    if (naturalSpeechMessage.isNotBlank()) Text(naturalSpeechMessage, color = Color(0xFF5BE0B0), fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 5.dp))
    OutlinedButton(
        onClick = { showRealExamples = !showRealExamples },
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFC56B))
    ) {
        Text(if (showRealExamples) "إخفاء المقطع الحقيقي ▲" else "▶ شاهد واستمع إلى أمثلة حقيقية — تركيز أمريكي")
    }
    if (showRealExamples) {
        PhraseExamplesInline(p.id, p.english)
    }
    val chunks = practiceChunks(p.english)
    if (chunks.size > 1) {
        Text("تدرب على المقاطع بالترتيب", color = Muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        chunks.forEachIndexed { index, chunk ->
            OutlinedButton(onClick = { onSpeakChunk(chunk) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Text("${index + 1}.  $chunk  •  استمع وكرر", color = Color(0xFFD8DFEB), textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
        OutlinedButton(onClick = onLoop) { Text("كرّر العبارة خمس مرات ${if (loopCount == 0) "" else "(جاهز)"}") }
    }
    Spacer(Modifier.height(12.dp)); Text("٢. سجّل وراجع صوتك", color = Muted, fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = if (recording) onStop else onRecord, colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFFE34E69) else Purple)) { Text(if (recording) "إيقاف وحفظ التسجيل" else "● سجّل صوتي") }
        OutlinedButton(onClick = onPlay, enabled = path.isNotBlank()) { Text("▶ استمع لتسجيلي", color = if (path.isBlank()) Muted else Cyan) }
    }
    Spacer(Modifier.height(12.dp)); Text("٣. التقييم الذكي", color = Muted, fontWeight = FontWeight.Bold)
    Text("يحوّل Android كلامك إلى نص، ثم نقارن الكلمات وترتيبها. هذا لا يقيس بدقة مخارج الأصوات أو النبر؛ اطّلع على IPA والنصيحة الصوتية وكرّر المقاطع المستهدفة.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End)
    Button(onClick = onTranscribe, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B876F)), modifier = Modifier.padding(top = 8.dp)) { Text(if (busy) "جارٍ التحليل..." else "🎙 قيّم نطقي") }
    if (transcript.isNotBlank()) InfoPanel("ما فهمه نظام التفريغ", transcript)
    if (score >= 0) {
        InfoPanel("مطابقة الكلمات وترتيبها: $score%", feedback)
        if (focusWords.isNotEmpty()) {
            Text("كلمات للتدريب", color = Muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                focusWords.forEach { word -> Pill("استمع: $word", false) { onSpeakWord(word) } }
            }
        }
        if (nextStep.isNotBlank()) InfoPanel("تدريبك التالي", nextStep)
    } else if (feedback.isNotBlank()) InfoPanel("ملاحظات المدرب", feedback)
    if (p.tip.isNotBlank()) PronunciationTip(p.tip, Modifier.padding(top = 10.dp))
}

@Composable private fun AddPhraseScreen(
    onAdd: (String, String, String, String, String, String) -> Unit,
    onGenerate: (String, String, String) -> Unit,
    generating: Boolean,
    generationMessage: String
) {
    var topic by remember { mutableStateOf("") }
    var english by remember { mutableStateOf("") }; var arabic by remember { mutableStateOf("") }; var ipa by remember { mutableStateOf("") }; var category by remember { mutableStateOf("محادثات يومية") }; var level by remember { mutableStateOf("متوسط") }; var tip by remember { mutableStateOf("") }
    Text("أضف عبارة جديدة", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    Spacer(Modifier.height(10.dp)); Field("العبارة الإنجليزية", english, { english = it }); Field("الترجمة العربية", arabic, { arabic = it }); Field("النطق الصوتي IPA (اختياري)", ipa, { ipa = it }); Field("ملاحظة أو نصيحة نطق", tip, { tip = it })
    Text("الموضوع", color = Muted); Row(Modifier.horizontalScroll(rememberScrollState())) { listOf("محادثات يومية", "العمل", "السفر", "تعابير", "روابط الطلاقة").forEach { Pill(it, category == it) { category = it } } }
    Text("المستوى", color = Muted); Row { listOf("مبتدئ", "متوسط", "متقدم").forEach { Pill(it, level == it) { level = it } } }
    Button(onClick = { onAdd(english, arabic, ipa, category, level, tip) }, enabled = english.isNotBlank() && arabic.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("حفظ العبارة") }
    Divider(color = Color(0xFF34415A), modifier = Modifier.padding(vertical = 18.dp))
    Text("توليد عبارات بالذكاء الاصطناعي المفتوح", color = Color(0xFFA49BFF), fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    Text("ينشئ خمس عبارات أمريكية طبيعية مع ترجمة عربية ونصيحة نطق، ثم يضيفها إلى مكتبتك دون تكرار.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End)
    Field("موضوع أو موقف (اختياري): مطعم، مقابلة عمل، حديث مع صديق...", topic, { topic = it })
    Button(onClick = { onGenerate(category, level, topic) }, enabled = !generating, colors = ButtonDefaults.buttonColors(containerColor = Cyan), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(if (generating) "جارٍ التوليد..." else "✦ ولّد 5 عبارات جديدة")
    }
    if (generationMessage.isNotBlank()) Text(generationMessage, color = if (generationMessage.contains("تم إنشاء")) Color(0xFF5BE0B0) else Color(0xFFFFC56B), fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
}

@Composable private fun ProgressScreen(total: Int, favorites: Int, mastered: Int, practices: Int, rate: Float, accent: String, endpoint: String, onRate: (Float) -> Unit, onAccent: (String) -> Unit, onEndpoint: (String) -> Unit) {
    Text("تقدمك وإعدادات التدريب", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatBox("العبارات", "$total", Modifier.weight(1f)); StatBox("المتقنة", "$mastered", Modifier.weight(1f)); StatBox("التدريبات", "$practices", Modifier.weight(1f)) }
    InfoPanel("المفضلة", "$favorites عبارة محفوظة للمراجعة")
    Text("سرعة الصوت", color = Muted); Row { listOf(.75f to "0.75×", 1f to "1.0×", 1.25f to "1.25×").forEach { (v, label) -> Pill(label, rate == v) { onRate(v) } } }
    Text("لهجة النطق", color = Muted, modifier = Modifier.padding(top = 12.dp)); Row { listOf("en-US" to "أمريكية", "en-GB" to "بريطانية", "en-AU" to "أسترالية (تستخدم الأمريكية)").forEach { (v, label) -> Pill(label, accent == v) { onAccent(v) } } }
    Text("مصادر البحث عن العبارات", color = Color(0xFFFFC56B), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
    Text("يوحّد مركز البحث الوصول إلى PlayPhrase وYARN وTED Corpus من واجهة واحدة. تفتح النتائج لدى المصدر الأصلي حالياً؛ لا نستخرج المقاطع ولا نضمّن مشغلاً ما لم يسمح المصدر بذلك صراحة. محرك الكابشن المحلي يدعم ملفات الوسائط والترجمات التي تختارها بنفسك.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp, textAlign = TextAlign.End)
    Text("اتصال مدرب AI الاختياري", color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp))
    Text("هذا الاتصال خاص بتحليل التدريب والتغذية الراجعة فقط؛ لا يستخدم للبحث عن الفيديوهات أو الكابشن. اتركه فارغاً لاستخدام التقييم المحلي للكلمات وترتيبها.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, textAlign = TextAlign.End)
    Field("https://your-domain.example/coach", endpoint, onEndpoint, singleLine = true)
    TtsSettingsPanel()
    Text("محركا الصوت المحليان: Pocket TTS وSupertonic 3. لا يحتاج أي منهما إلى مفتاح API أو اتصال أثناء النطق.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
}

@Composable private fun TtsSettingsPanel() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("shadow-ai", 0) }
    val scope = rememberCoroutineScope()
    var engine by remember { mutableStateOf((prefs.getString("tts_engine", "pocket") ?: "pocket").let { if (it == "supertonic") "supertonic" else "pocket" }) }
    SideEffect { if (prefs.getString("tts_engine", "pocket") !in setOf("pocket", "supertonic")) prefs.edit().putString("tts_engine", "pocket").apply() }
    var pocketVoice by remember { mutableStateOf(prefs.getString("pocket_voice", "alba") ?: "alba") }
    var superVoice by remember { mutableIntStateOf(prefs.getInt("supertonic_speaker", 6)) }
    var pocketReady by remember { mutableStateOf(PocketTtsEngine.isModelReady(context)) }
    var superReady by remember { mutableStateOf(SupertonicTtsEngine.isModelReady(context)) }
    var downloadProgress by remember { mutableIntStateOf(0) }
    var downloading by remember { mutableStateOf(false) }
    var ttsMessage by remember { mutableStateOf("") }

    Text("محرك النطق المحلي", color = Color(0xFFFFC56B), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pill("Pocket TTS", engine == "pocket") { engine = "pocket"; prefs.edit().putString("tts_engine", engine).apply() }
        Pill("Supertonic 3", engine == "supertonic") { engine = "supertonic"; prefs.edit().putString("tts_engine", engine).apply() }
    }

    if (engine == "pocket") {
        Text("Pocket TTS محرك محلي يعمل دون إنترنت بعد تنزيل نموذجه مرة واحدة. الصوت يخرج مباشرة بصيغة PCM ولا تُنشأ ملفات MP3 دائمة.", color = Color(0xFF7EDCB5), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        Text("أصوات Pocket TTS", color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("alba" to "Alba", "marius" to "Marius", "javert" to "Javert", "jean" to "Jean").forEach { (id, label) -> Pill(label, pocketVoice == id) { pocketVoice = id; prefs.edit().putString("pocket_voice", id).apply() } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("cosette" to "Cosette", "eponine" to "Eponine", "fantine" to "Fantine", "azelma" to "Azelma").forEach { (id, label) -> Pill(label, pocketVoice == id) { pocketVoice = id; prefs.edit().putString("pocket_voice", id).apply() } }
        }
        if (!pocketReady) {
            Button(onClick = {
                if (!downloading) scope.launch {
                    downloading = true; downloadProgress = 0; ttsMessage = "بدء تنزيل نموذج Pocket TTS..."
                    try {
                        withContext(Dispatchers.IO) { PocketTtsEngine.downloadModel(context.applicationContext) { v -> android.os.Handler(android.os.Looper.getMainLooper()).post { downloadProgress = v } } }
                        pocketReady = true; ttsMessage = "اكتمل تنزيل Pocket TTS وأصبح جاهزاً دون إنترنت."
                    } catch (e: Exception) { ttsMessage = "فشل التنزيل: ${e.message ?: "خطأ غير معروف"}" }
                    finally { downloading = false }
                }
            }, enabled = !downloading, colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth()) { Text(if (downloading) "جارٍ التنزيل: $downloadProgress%" else "تنزيل نموذج Pocket TTS (حوالي 163 MB)") }
        } else Text("نموذج Pocket TTS مثبت وجاهز.", color = Color(0xFF7EDCB5), fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    } else {
        Text("Supertonic 3 • نموذج عصبي متعدد اللغات يعمل محلياً عبر ONNX Runtime. يتطلب تنزيل ملفات النموذج مرة واحدة (نحو 133 MB وفق حزمة الهاتف المختارة)، ثم يعمل دون إنترنت. عشرة أصوات، خمسة نسائية وخمسة رجالية.", color = Color(0xFF7EDCB5), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        Text("اختيار الصوت", color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (0..4).forEach { id -> Pill("F${id + 1}", superVoice == id) { superVoice = id; prefs.edit().putInt("supertonic_speaker", id).apply() } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (5..9).forEach { id -> Pill("M${id - 4}", superVoice == id) { superVoice = id; prefs.edit().putInt("supertonic_speaker", id).apply() } }
        }
        if (!superReady) {
            Button(onClick = {
                if (!downloading) scope.launch {
                    downloading = true; downloadProgress = 0; ttsMessage = "بدء تنزيل ملفات Supertonic 3..."
                    try {
                        withContext(Dispatchers.IO) { SupertonicTtsEngine.downloadModel(context.applicationContext) { v -> android.os.Handler(android.os.Looper.getMainLooper()).post { downloadProgress = v } } }
                        superReady = true; ttsMessage = "اكتمل تنزيل ملفات Supertonic 3 وفُحصت سلامتها."
                    } catch (e: Exception) { ttsMessage = "فشل تنزيل Supertonic: ${e.message ?: "خطأ غير معروف"}" }
                    finally { downloading = false }
                }
            }, enabled = !downloading, colors = ButtonDefaults.buttonColors(containerColor = Purple), modifier = Modifier.fillMaxWidth()) { Text(if (downloading) "جارٍ التنزيل: $downloadProgress%" else "تنزيل Supertonic 3 (حوالي 133 MB)") }
        } else Text("ملفات Supertonic 3 مثبتة وجاهزة.", color = Color(0xFF7EDCB5), fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
    }

    val ready = if (engine == "pocket") pocketReady else superReady
    if (ready) {
        Button(onClick = {
            TtsEngineManager.speak(context.applicationContext, "I was just wondering.", 1f, "en-US", false) { message -> android.os.Handler(android.os.Looper.getMainLooper()).post { ttsMessage = message } }
            ttsMessage = "جارٍ اختبار الصوت: I was just wondering."
        }, colors = ButtonDefaults.buttonColors(containerColor = Cyan), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("اختبار الصوت: I was just wondering") }
    }
    if (ttsMessage.isNotBlank()) Text(ttsMessage, color = if (ttsMessage.contains("فشل") || ttsMessage.contains("تعذر")) Color(0xFFFF9C8E) else Muted, fontSize = 11.sp, lineHeight = 16.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
}

@Composable private fun Field(label: String, value: String, onValue: (String) -> Unit, singleLine: Boolean = false) { OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), singleLine = singleLine, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF37445E), focusedLabelColor = Color(0xFFA49BFF), unfocusedLabelColor = Muted)) }
@Composable private fun SmallBadge(text: String, color: Color) { Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(color.copy(alpha = .14f), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 8.dp)) }
@Composable private fun Pill(text: String, selected: Boolean, onClick: () -> Unit) { TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 1.dp), colors = ButtonDefaults.textButtonColors(containerColor = if (selected) Purple else Panel, contentColor = Color.White), shape = RoundedCornerShape(12.dp)) { Text(text, fontSize = 12.sp, maxLines = 1) } }
@Composable private fun PronunciationTip(tip: String, modifier: Modifier = Modifier) {
    var expanded by remember(tip) { mutableStateOf(false) }
    Column(
        modifier.fillMaxWidth()
            .background(Color(0xFF202746), RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFF41458B), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        TextButton(
            onClick = { expanded = !expanded },
            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (expanded) "⌃" else "⌄", color = Muted, fontSize = 18.sp)
                Text(
                    "نصيحة النطق والربط الصوتي (Connected Speech)",
                    color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold,
                    fontSize = 13.sp, textAlign = TextAlign.End
                )
            }
        }
        if (expanded) {
            Text(
                tip, color = Color(0xFFD8DFEB), fontSize = 13.sp,
                textAlign = TextAlign.End, lineHeight = 21.sp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp)
            )
        }
    }
}
@Composable private fun InfoPanel(title: String, text: String) { Column(Modifier.fillMaxWidth().padding(top = 12.dp).background(Color(0xFF202746), RoundedCornerShape(14.dp)).padding(13.dp)) { Text(title, color = Color(0xFFA49BFF), fontWeight = FontWeight.Bold); Text(text, color = Color(0xFFD8DFEB), textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), lineHeight = 20.sp) } }
@Composable private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) { Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp); Text(label, color = Muted, fontSize = 11.sp) } }
@Composable private fun EmptyText(text: String) { Text(text, color = Muted, modifier = Modifier.fillMaxWidth().padding(30.dp), textAlign = TextAlign.Center) }

private fun practiceChunks(text: String): List<String> {
    val byPunctuation = text.split(Regex("(?<=[,;.!?])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
    if (byPunctuation.size > 1) return byPunctuation
    val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    if (words.size <= 7) return emptyList()
    val chunks = mutableListOf<String>()
    var current = mutableListOf<String>()
    val joiners = setOf("and", "but", "because", "although", "so", "if", "when", "while", "unless", "that")
    for (word in words) {
        if (current.size >= 3 && word.trim(',', ';', '.', '?', '!').lowercase(Locale.US) in joiners) {
            chunks.add(current.joinToString(" ")); current = mutableListOf()
        }
        current.add(word)
        if (current.size >= 5) { chunks.add(current.joinToString(" ")); current = mutableListOf() }
    }
    if (current.isNotEmpty()) {
        if (chunks.isNotEmpty() && current.size <= 2) chunks[chunks.lastIndex] = chunks.last() + " " + current.joinToString(" ")
        else chunks.add(current.joinToString(" "))
    }
    return chunks.filter { it.isNotBlank() }
}

private fun readPhrases(prefs: android.content.SharedPreferences, context: android.content.Context): List<Phrase> {
    val allDefaults = seedPhrases + importedPhrases(context)
    return try {
        val raw = prefs.getString("phrases", null) ?: return allDefaults
        val saved = JSONArray(raw).let { array -> (0 until array.length()).map { i -> array.getJSONObject(i).toPhrase() } }
        val defaultsById = allDefaults.associateBy { it.id }
        val refreshed = saved.map { old ->
            val base = defaultsById[old.id] ?: return@map old
            base.copy(favorite = old.favorite, mastered = old.mastered, practiceCount = old.practiceCount,
                recordingPath = old.recordingPath, custom = old.custom)
        }
        refreshed + allDefaults.filter { seed -> saved.none { it.id == seed.id } }
    } catch (_: Exception) { allDefaults }
}
private fun writePhrases(items: List<Phrase>): String = JSONArray().apply { items.forEach { put(it.toJson()) } }.toString()
private fun speechIntent(accent: String) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_LANGUAGE, accent)
    putExtra(RecognizerIntent.EXTRA_PROMPT, "انطق العبارة الإنجليزية")
    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
}
private fun Phrase.toJson() = JSONObject().put("id", id).put("english", english).put("ipa", ipa).put("arabic", arabic).put("level", level).put("category", category).put("tip", tip).put("favorite", favorite).put("mastered", mastered).put("practiceCount", practiceCount).put("recordingPath", recordingPath).put("custom", custom)
private fun JSONObject.toPhrase() = Phrase(optString("id"), optString("english"), optString("ipa"), optString("arabic"), optString("level", "متوسط"), optString("category", "محادثات يومية"), optString("tip"), optBoolean("favorite"), optBoolean("mastered"), optInt("practiceCount"), optString("recordingPath"), optBoolean("custom"))
