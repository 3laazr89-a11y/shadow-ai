package com.example.shadowingai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object CoachService {
    data class Result(
        val score: Int,
        val feedback: String,
        val transcript: String,
        val viaAi: Boolean,
        val missingWords: List<String> = emptyList(),
        val extraWords: List<String> = emptyList(),
        val substitutions: List<String> = emptyList(),
        val focusWords: List<String> = emptyList(),
        val nextStep: String = ""
    )

    private data class Alignment(
        val missing: List<String>,
        val extra: List<String>,
        val substitutions: List<String>,
        val edits: Int
    )

    /** Local score compares recognized words and their order; it does not assess the sound itself. */
    fun local(expected: String, transcript: String): Result {
        val target = words(expected)
        val spoken = words(transcript)
        if (transcript.isBlank()) {
            return Result(
                0,
                "لم أتمكن من تمييز العبارة. اقترب من الميكروفون، وتحدث بوضوح، ثم حاول مجددًا.",
                transcript,
                false,
                nextStep = "استمع إلى العبارة ببطء مرة واحدة، ثم أعد التسجيل في مكان هادئ."
            )
        }
        if (target.isEmpty()) return Result(0, "لا توجد كلمات مستهدفة للمقارنة.", transcript, false)

        val aligned = align(target, spoken)
        val denominator = maxOf(target.size, spoken.size).coerceAtLeast(1)
        val score = ((100.0 * (denominator - aligned.edits).coerceAtLeast(0) / denominator).toInt()).coerceIn(0, 100)
        val missing = aligned.missing.distinct().take(5)
        val extra = aligned.extra.distinct().take(4)
        val substitutions = aligned.substitutions.distinct().take(4)
        val detail = when {
            score >= 95 -> "رائع؛ التفريغ التقط الكلمات بالترتيب الصحيح. انتقل الآن إلى محاكاة الإيقاع والربط، فهذه النتيجة لا تقيس مخارج الأصوات مباشرة."
            missing.isNotEmpty() && substitutions.isNotEmpty() -> "التفريغ لم يلتقط ${missing.joinToString(", ")}، وسمع بدلًا من ذلك ${substitutions.joinToString("؛ ")}. درّب الكلمات موضع التركيز منفردة ثم أعد وصل العبارة."
            missing.isNotEmpty() -> "الكلمات التي لم تظهر في التفريغ: ${missing.joinToString(", ")}. انطقها بوضوح داخل العبارة، ولا تتوقف طويلًا بين الكلمات."
            substitutions.isNotEmpty() -> "تحقق من هذه الكلمات التي ربما نُطقت أو فُرّغت بصورة مختلفة: ${substitutions.joinToString("؛ ")}. قارن الصوت النموذجي بها مقطعًا مقطعًا."
            extra.isNotEmpty() -> "ظهر في التفريغ كلام زائد (${extra.joinToString(", ")}). أعد العبارة على دفعات قصيرة مع وقفة طبيعية فقط عند علامات الترقيم."
            else -> "العبارة قريبة من الهدف. أعد الاستماع وركّز على النبر والربط بين الكلمات غير المشددة."
        }
        val focus = (missing + substitutions.map { it.substringBefore(" → ") }).distinct().take(3)
        val next = when {
            focus.isNotEmpty() -> "تمرينك التالي: استمع إلى ${focus.joinToString(", ")} ببطء، كرر كل كلمة مرتين، ثم قل العبارة كاملة بسرعة طبيعية."
            extra.isNotEmpty() -> "تمرينك التالي: قل كل مقطع مرة واحدة بإيقاع ثابت، ثم أعد العبارة كاملة دون إضافة كلمات."
            else -> "تمرينك التالي: كرر العبارة مع وصل الكلمات الخفيفة، وحافظ على وضوح الكلمات التي تحمل النبر."
        }
        return Result(score, detail, transcript, false, missing, extra, substitutions, focus, next)
    }

    /** Endpoint input: {expected, transcript, ipa, tip, language}; response includes deterministic score and AI feedback/focusWords/nextStep. */
    fun analyze(
        endpoint: String,
        expected: String,
        transcript: String,
        ipa: String = "",
        tip: String = "",
        language: String = "en-US"
    ): Result {
        val local = local(expected, transcript)
        if (endpoint.isBlank()) return local
        if (!endpoint.startsWith("https://", ignoreCase = true)) {
            return local.copy(feedback = "يقبل التطبيق عنوان HTTPS آمنًا فقط؛ أُظهر تحليل الكلمات المحلي بدلًا من إرسال البيانات.")
        }
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12_000
                readTimeout = 22_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            val payload = JSONObject()
                .put("expected", expected)
                .put("transcript", transcript)
                .put("ipa", ipa)
                .put("tip", tip)
                .put("language", language)
                .toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                return local.copy(feedback = "تعذر الوصول إلى خدمة AI (HTTP $code). تحليل الكلمات المحلي: ${local.feedback}")
            }
            val json = JSONObject(body)
            val focus = json.optJSONArray("focusWords").asStrings().take(3)
            Result(
                score = local.score,
                feedback = json.optString("feedback").ifBlank { local.feedback },
                transcript = transcript,
                viaAi = true,
                missingWords = local.missingWords,
                extraWords = local.extraWords,
                substitutions = local.substitutions,
                focusWords = focus.ifEmpty { local.focusWords },
                nextStep = json.optString("nextStep").ifBlank { local.nextStep }
            )
        } catch (_: Exception) {
            local.copy(feedback = "تعذر الاتصال بخدمة AI؛ عُرض تحليل الكلمات المحلي بدلًا منها. ${local.feedback}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun JSONArray?.asStrings(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { optString(it).takeIf(String::isNotBlank) }
    }

    private fun align(target: List<String>, spoken: List<String>): Alignment {
        val rows = target.size + 1
        val cols = spoken.size + 1
        val dp = Array(rows) { IntArray(cols) }
        for (i in 0 until rows) dp[i][0] = i
        for (j in 0 until cols) dp[0][j] = j
        for (i in 1 until rows) for (j in 1 until cols) {
            val substitutionCost = if (target[i - 1] == spoken[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + substitutionCost)
        }
        val missing = mutableListOf<String>()
        val extra = mutableListOf<String>()
        val substitutions = mutableListOf<String>()
        var i = target.size
        var j = spoken.size
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && target[i - 1] == spoken[j - 1] && dp[i][j] == dp[i - 1][j - 1]) {
                i--; j--
            } else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
                substitutions.add(0, "${target[i - 1]} → ${spoken[j - 1]}")
                i--; j--
            } else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                missing.add(0, target[i - 1]); i--
            } else {
                extra.add(0, spoken[j - 1]); j--
            }
        }
        return Alignment(missing, extra, substitutions, dp[target.size][spoken.size])
    }

    private fun words(s: String): List<String> = s.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9']+"), " ")
        .trim()
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
}
