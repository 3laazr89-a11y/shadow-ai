package com.example.shadowingai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Calls the user's own OpenAI-compatible backend; the model itself can be open-weight and self-hosted. */
object PhraseGenerator {
    data class GeneratedPhrase(val english: String, val arabic: String, val ipa: String, val tip: String)

    fun generate(coachEndpoint: String, category: String, level: String, topic: String = "", count: Int = 5): List<GeneratedPhrase> {
        require(coachEndpoint.startsWith("https://", true)) { "أدخل عنوان HTTPS لخادم الذكاء الاصطناعي في صفحة التقدم والإعدادات أولاً." }
        val base = coachEndpoint.trim().removeSuffix("/").removeSuffix("/coach")
        val url = URL("$base/generate-phrases")
        var connection: HttpURLConnection? = null
        try {
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            val request = JSONObject()
                .put("category", category)
                .put("level", level)
                .put("topic", topic)
                .put("count", count.coerceIn(1, 8))
            connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException(
                when (code) {
                    503 -> "خدمة توليد العبارات غير مهيأة على الخادم. تحقق من AI_MODEL."
                    504 -> "استغرق النموذج وقتاً أطول من اللازم. جرّب عدداً أقل من العبارات."
                    else -> "فشل توليد العبارات (HTTP $code). تحقق من إعداد الخادم والنموذج."
                }
            )
            val array: JSONArray = JSONObject(body).optJSONArray("phrases")
                ?: throw IllegalStateException("استجابة النموذج لا تحتوي قائمة عبارات صالحة.")
            val seen = HashSet<String>()
            return (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                val english = item.optString("english").trim()
                val arabic = item.optString("arabic").trim()
                if (english.length < 8 || arabic.isBlank() || !seen.add(english.lowercase())) return@mapNotNull null
                GeneratedPhrase(english, arabic, item.optString("ipa"), item.optString("tip"))
            }.take(count).also { if (it.isEmpty()) throw IllegalStateException("لم يُنتج النموذج عبارات قابلة للحفظ. أعد المحاولة.") }
        } finally { connection?.disconnect() }
    }
}
