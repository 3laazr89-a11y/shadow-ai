package com.example.shadowingai

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

internal data class CaptionSegment(
    val id: Long,
    val sourceTitle: String,
    val sourceCategory: String,
    val mediaUri: String,
    val startMs: Long,
    val endMs: Long,
    val text: String
)

private class CaptionIndexDb(context: Context) : SQLiteOpenHelper(context, "shadow_caption_index.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE caption_segments (id INTEGER PRIMARY KEY AUTOINCREMENT, source_title TEXT NOT NULL, source_category TEXT NOT NULL, media_uri TEXT NOT NULL, start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL, text TEXT NOT NULL)")
        db.execSQL("CREATE VIRTUAL TABLE caption_fts USING fts4(text, segment_id UNINDEXED)")
        db.execSQL("CREATE INDEX caption_segments_media_idx ON caption_segments(media_uri)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun insert(sourceTitle: String, sourceCategory: String, mediaUri: String, cues: List<CaptionCue>): Int {
        val db = writableDatabase
        var inserted = 0
        db.beginTransaction()
        try {
            // Re-importing the same media replaces its old caption index rather than duplicating it.
            val oldIds = mutableListOf<Long>()
            db.rawQuery("SELECT id FROM caption_segments WHERE media_uri = ?", arrayOf(mediaUri)).use { c ->
                while (c.moveToNext()) oldIds += c.getLong(0)
            }
            oldIds.forEach { id ->
                db.delete("caption_fts", "segment_id = CAST(? AS INTEGER)", arrayOf(id.toString()))
            }
            db.delete("caption_segments", "media_uri = ?", arrayOf(mediaUri))
            cues.forEach { cue ->
                val values = ContentValues().apply {
                    put("source_title", sourceTitle)
                    put("source_category", sourceCategory)
                    put("media_uri", mediaUri)
                    put("start_ms", cue.startMs)
                    put("end_ms", cue.endMs)
                    put("text", cue.text)
                }
                val id = db.insert("caption_segments", null, values)
                if (id > 0) {
                    db.insert("caption_fts", null, ContentValues().apply {
                        put("text", cue.text)
                        put("segment_id", id)
                    })
                    inserted++
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return inserted
    }

    fun search(rawQuery: String, limit: Int = 150): List<CaptionSegment> {
        val query = rawQuery.trim().replace(Regex("\\s+"), " ")
        if (query.isBlank()) return emptyList()
        val db = readableDatabase
        val phraseQuery = "\"${query.replace("\"", "\"\"")}\""
        val rows = mutableListOf<CaptionSegment>()
        val sql = "SELECT s.id, s.source_title, s.source_category, s.media_uri, s.start_ms, s.end_ms, s.text FROM caption_fts JOIN caption_segments s ON s.id = CAST(caption_fts.segment_id AS INTEGER) WHERE caption_fts MATCH ? ORDER BY s.source_title COLLATE NOCASE LIMIT ?"
        try {
            db.rawQuery(sql, arrayOf(phraseQuery, limit.toString())).use { c ->
                while (c.moveToNext()) rows += c.toSegment()
            }
        } catch (_: Exception) {
            // FTS syntax can reject punctuation-heavy user input; use a safe literal fallback.
        }
        if (rows.isNotEmpty()) return rows
        val tokens = query.split(Regex("[^\\p{L}\\p{N}']+")).filter { it.length >= 2 }.take(8)
        if (tokens.isEmpty()) return emptyList()
        val where = tokens.joinToString(" AND ") { "text LIKE ? ESCAPE '\\'" }
        val args = tokens.map { "%${it.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")}%" }.toTypedArray()
        db.rawQuery("SELECT id, source_title, source_category, media_uri, start_ms, end_ms, text FROM caption_segments WHERE $where ORDER BY source_title COLLATE NOCASE LIMIT $limit", args).use { c ->
            while (c.moveToNext()) rows += c.toSegment()
        }
        return rows
    }

    fun counts(): Pair<Int, Int> {
        val db = readableDatabase
        val sources = db.rawQuery("SELECT COUNT(DISTINCT media_uri) FROM caption_segments", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        val segments = db.rawQuery("SELECT COUNT(*) FROM caption_segments", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return sources to segments
    }

    private fun android.database.Cursor.toSegment() = CaptionSegment(
        id = getLong(0), sourceTitle = getString(1), sourceCategory = getString(2), mediaUri = getString(3),
        startMs = getLong(4), endMs = getLong(5), text = getString(6)
    )
}

private data class CaptionCue(val startMs: Long, val endMs: Long, val text: String)

internal object CaptionImporter {
    fun importCaptions(context: Context, subtitleUri: Uri, mediaUri: Uri, sourceCategory: String): Int {
        val subtitleText = context.contentResolver.openInputStream(subtitleUri)?.use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText().removePrefix("\uFEFF")
        } ?: throw IllegalStateException("تعذرت قراءة ملف الترجمة")
        val cues = parse(subtitleText)
        if (cues.isEmpty()) throw IllegalArgumentException("لم أجد مقاطع ترجمة صالحة. استخدم ملف SRT أو VTT.")
        val title = displayName(context.contentResolver, mediaUri) ?: mediaUri.lastPathSegment ?: "مصدر مستورد"
        return CaptionIndexDb(context).use { it.insert(title, sourceCategory, mediaUri.toString(), cues) }
    }

    fun displayName(resolver: ContentResolver, uri: Uri): String? = try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun parse(raw: String): List<CaptionCue> {
        val normalized = raw.replace("\r\n", "\n").replace('\r', '\n')
        val blocks = normalized.split(Regex("\\n\\s*\\n"))
        val timePattern = Regex("(?:(\\d{1,2}):)?(\\d{2}):(\\d{2})[,.](\\d{3})\\s*-->\\s*(?:(\\d{1,2}):)?(\\d{2}):(\\d{2})[,.](\\d{3})")
        val cues = mutableListOf<CaptionCue>()
        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotBlank() }
            val timeIndex = lines.indexOfFirst { timePattern.containsMatchIn(it) }
            if (timeIndex < 0) continue
            val match = timePattern.find(lines[timeIndex]) ?: continue
            fun time(h: String?, m: String, s: String, ms: String): Long =
                (((h?.toLongOrNull() ?: 0L) * 3600 + (m.toLongOrNull() ?: 0L) * 60 + (s.toLongOrNull() ?: 0L)) * 1000) + (ms.toLongOrNull() ?: 0L)
            val start = time(match.groupValues[1].takeIf { it.isNotBlank() }, match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val end = time(match.groupValues[5].takeIf { it.isNotBlank() }, match.groupValues[6], match.groupValues[7], match.groupValues[8])
            val text = lines.drop(timeIndex + 1).joinToString(" ")
                .replace(Regex("<[^>]*>"), "")
                .replace(Regex("\\{\\\\an[1-9]\\}"), "")
                .replace("&nbsp;", " ").replace("&amp;", "&").trim()
            if (text.isNotBlank() && end >= start) cues += CaptionCue(start, end, text)
        }
        return cues
    }
}

@Composable
internal fun CaptionSearchScreen(
    onImport: (String) -> Unit,
    importMessage: String,
    onPlay: (CaptionSegment) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var query by remember { mutableStateOf("") }
    var sourceCategory by remember { mutableStateOf("أفلام ومسلسلات") }
    var results by remember { mutableStateOf(emptyList<CaptionSegment>()) }
    var searching by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    var counts by remember { mutableStateOf(0 to 0) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(importMessage) {
        counts = withContext(Dispatchers.IO) { CaptionIndexDb(context).use { it.counts() } }
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Text("محرك البحث في الكابشن", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("ابحث داخل نص الكلام نفسه، ثم افتح المقطع من توقيت العبارة.", color = Color(0xFF9AA6BB), fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.padding(top = 5.dp, bottom = 12.dp))
        Text("نوع المحتوى", color = Color(0xFF9AA6BB), fontSize = 11.sp, modifier = Modifier.padding(bottom = 5.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("أفلام ومسلسلات", "بودكاست", "محاضرات", "تقارير علمية", "لقاءات", "أخرى").forEach { category ->
                FilterChip(selected = sourceCategory == category, onClick = { sourceCategory = category }, label = { Text(category, fontSize = 10.sp, maxLines = 1) })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { onImport(sourceCategory) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF625CF0)), modifier = Modifier.weight(1f)) { Text("استيراد ترجمة + وسيط") }
            Surface(color = Color(0xFF182438), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(counts.second.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                    Text("مقطع", color = Color(0xFF9AA6BB), fontSize = 10.sp)
                }
            }
        }
        if (importMessage.isNotBlank()) Text(importMessage, color = Color(0xFF8EDCC1), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("اكتب كلمة أو عبارة من الكابشن...", color = Color(0xFF8793A8)) },
            singleLine = false, minLines = 2, shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color(0xFF8A83FF), unfocusedBorderColor = Color(0xFF39445A), cursorColor = Color.White)
        )
        Button(onClick = {
            searching = true; searched = true; error = ""
            scope.launch {
                try { results = withContext(Dispatchers.IO) { CaptionIndexDb(context).use { it.search(query) } } }
                catch (e: Exception) { results = emptyList(); error = e.message ?: "تعذر تنفيذ البحث" }
                searching = false
            }
        }, enabled = query.isNotBlank() && !searching, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF625CF0))) {
            Text(if (searching) "جارٍ البحث..." else "ابحث في الكابشن")
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B9B), fontSize = 12.sp)
        if (searched && !searching) Text("${results.size} نتيجة في الفهرس المحلي", color = Color(0xFF9AA6BB), fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        if (results.isNotEmpty()) {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 430.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results, key = { it.id }) { result ->
                    Column(Modifier.fillMaxWidth().background(Color(0xFF182438), RoundedCornerShape(14.dp)).border(1.dp, Color(0xFF303D54), RoundedCornerShape(14.dp)).clickable { onPlay(result) }.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${formatCaptionTime(result.startMs)} → ${formatCaptionTime(result.endMs)}", color = Color(0xFFFFC56B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${result.sourceCategory} • ${result.sourceTitle}", color = Color(0xFF9AA6BB), fontSize = 11.sp, maxLines = 1)
                        }
                        Text(result.text, color = Color.White, fontSize = 15.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 7.dp))
                        Text("اضغط للتشغيل من موضع العبارة  ▶", color = Color(0xFF8EDCC1), fontSize = 11.sp, modifier = Modifier.align(Alignment.End).padding(top = 7.dp))
                    }
                }
            }
        } else if (searched && !searching && error.isBlank()) {
            Text("لا توجد نتائج. أضف ملف ترجمة SRT أو VTT أولاً، ثم ابحث عن العبارة.", color = Color(0xFF9AA6BB), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 18.dp))
        } else if (!searched) {
            Text("يدعم الإصدار الأول ملفات SRT وVTT من ملفاتك أو من مصادر تسمح باستخدامها. تتم الفهرسة محلياً على الجهاز.", color = Color(0xFF9AA6BB), fontSize = 11.sp, lineHeight = 17.sp, textAlign = TextAlign.End, modifier = Modifier.padding(top = 14.dp))
        }
    }
}

@Composable
internal fun CaptionPlayerDialog(segment: CaptionSegment, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        BackHandler(onBack = onDismiss)
        Surface(Modifier.fillMaxWidth().padding(12.dp), color = Color(0xFF0C1422), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDismiss) { Text("إغلاق", color = Color(0xFFAAB5C9)) }
                    Text("تشغيل من لحظة العبارة", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Text(segment.text, color = Color(0xFFFFC56B), textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
                AndroidView(
                    modifier = Modifier.fillMaxWidth().height(230.dp).background(Color.Black, RoundedCornerShape(12.dp)),
                    factory = { context ->
                        VideoView(context).apply {
                            val controller = MediaController(context)
                            controller.setAnchorView(this)
                            setMediaController(controller)
                            setOnErrorListener { _, _, _ -> true }
                        }
                    },
                    update = { view -> if (view.tag != segment.id) { view.tag = segment.id; view.setVideoURI(Uri.parse(segment.mediaUri)); view.setOnPreparedListener { player -> player.seekTo(segment.startMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()); player.start() } } },
                    onRelease = { it.stopPlayback() }
                )
                Text("${segment.sourceCategory} • ${segment.sourceTitle} • ${formatCaptionTime(segment.startMs)}", color = Color(0xFF9AA6BB), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                Text("يستخدم المشغل ملف الوسائط الذي اخترته مع ملف الترجمة. قد يختلف دعم الصيغ حسب جهازك.", color = Color(0xFF9AA6BB), fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

private fun formatCaptionTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0) / 1000)
    return String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
}
