package com.example.shadowingai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/** Supertonic 3 offline TTS via sherpa-onnx. Model files are downloaded once to app-private storage. */
internal object SupertonicTtsEngine {
    private const val MODEL_DIR = "supertonic-3-mobile"
    private const val BASE_URL = "https://huggingface.co/WilburDev/supertonic-3-mobile/resolve/main/"
    private data class ModelFile(val name: String, val minimumBytes: Long)
    private val files = listOf(
        ModelFile("duration_predictor.onnx", 2L * 1024 * 1024),
        ModelFile("text_encoder.onnx", 20L * 1024 * 1024),
        ModelFile("vector_estimator.int8.onnx", 40L * 1024 * 1024),
        ModelFile("vocoder.int8.onnx", 15L * 1024 * 1024),
        ModelFile("tts.json", 2_000L),
        ModelFile("unicode_indexer.bin", 100_000L),
        ModelFile("voice.bin", 100_000L),
    )
    private val lock = Any()
    @Volatile private var tts: OfflineTts? = null
    @Volatile private var activeTrack: AudioTrack? = null
    private val cancelled = AtomicBoolean(false)

    fun modelDir(context: Context) = File(context.filesDir, MODEL_DIR)
    fun isModelReady(context: Context): Boolean {
        val dir = modelDir(context)
        return files.all { f -> File(dir, f.name).let { it.isFile && it.length() >= f.minimumBytes } }
    }

    fun downloadModel(context: Context, progress: (Int) -> Unit) {
        if (isModelReady(context)) { progress(100); return }
        val dir = modelDir(context).apply { mkdirs() }
        val completed = files.sumOf { f -> File(dir, f.name).takeIf { it.isFile && it.length() >= f.minimumBytes }?.length() ?: 0L }
        val knownTotal = files.sumOf { it.minimumBytes }
        var baseDone = completed
        for (modelFile in files) {
            val target = File(dir, modelFile.name)
            if (target.isFile && target.length() >= modelFile.minimumBytes) continue
            val partial = File(dir, modelFile.name + ".part")
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(BASE_URL + modelFile.name + "?download=true").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30000
                    readTimeout = 180000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "ShadowingAI-Android/3.9.15")
                }
                val code = connection.responseCode
                check(code == HttpURLConnection.HTTP_OK) { "تعذر تنزيل ${modelFile.name} (HTTP $code)." }
                var received = 0L
                val total = connection.contentLengthLong
                connection.inputStream.use { input ->
                    partial.outputStream().buffered().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                            received += n
                            val current = baseDone + received
                            val estimated = if (total > 0) (current * 100 / (knownTotal - modelFile.minimumBytes + total)).toInt() else (current * 100 / knownTotal).toInt()
                            progress(estimated.coerceIn(0, 99))
                        }
                    }
                }
                check(received >= modelFile.minimumBytes) { "ملف ${modelFile.name} ناقص (${received} بايت). أعد التنزيل." }
                if (total > 0) check(received == total) { "انقطع تنزيل ${modelFile.name}. أعد المحاولة." }
                if (target.exists()) target.delete()
                check(partial.renameTo(target)) { "تعذر تثبيت ${modelFile.name}." }
                baseDone += received
            } catch (e: Exception) {
                partial.delete()
                throw e
            } finally { connection?.disconnect() }
        }
        check(isModelReady(context)) { "اكتمل التنزيل لكن فحص ملفات Supertonic لم ينجح." }
        progress(100)
    }

    private fun getEngine(context: Context): OfflineTts {
        synchronized(lock) {
            tts?.let { return it }
            check(isModelReady(context)) { "نزّل نموذج Supertonic 3 أولاً من إعدادات الصوت." }
            val dir = modelDir(context)
            val model = OfflineTtsSupertonicModelConfig(
                durationPredictor = File(dir, "duration_predictor.onnx").absolutePath,
                textEncoder = File(dir, "text_encoder.onnx").absolutePath,
                vectorEstimator = File(dir, "vector_estimator.int8.onnx").absolutePath,
                vocoder = File(dir, "vocoder.int8.onnx").absolutePath,
                ttsJson = File(dir, "tts.json").absolutePath,
                unicodeIndexer = File(dir, "unicode_indexer.bin").absolutePath,
                voiceStyle = File(dir, "voice.bin").absolutePath,
            )
            val config = OfflineTtsConfig(
                model = OfflineTtsModelConfig(supertonic = model, numThreads = 4, debug = false, provider = "cpu")
            )
            return OfflineTts(config = config).also { created ->
                check(created.numSpeakers() == 10) { "ملف أصوات Supertonic غير متوافق (عدد الأصوات ${created.numSpeakers()})." }
                tts = created
            }
        }
    }

    fun speak(context: Context, text: String, speed: Float, speakerId: Int) {
        require(text.isNotBlank()) { "النص فارغ." }
        cancelled.set(false)
        val engine = getEngine(context.applicationContext)
        val sampleRate = engine.sampleRate()
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        require(minBuffer > 0) { "تعذر تهيئة مخرج صوت Supertonic." }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).build())
            .setBufferSizeInBytes(maxOf(minBuffer * 2, sampleRate * 4 / 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        activeTrack = track
        var writeFailure: String? = null
        var totalWritten = 0L
        try {
            track.play()
            val generation = GenerationConfig(
                sid = speakerId.coerceIn(0, 9),
                numSteps = 5,
                speed = speed.coerceIn(0.7f, 1.3f),
                extra = mapOf("lang" to "en")
            )
            engine.generateWithConfigAndCallback(text, generation) { samples ->
                if (cancelled.get()) return@generateWithConfigAndCallback 0
                var offset = 0
                while (offset < samples.size && !cancelled.get()) {
                    val written = track.write(samples, offset, samples.size - offset, AudioTrack.WRITE_BLOCKING)
                    if (written < 0) { writeFailure = "فشل إخراج صوت Supertonic ($written)."; return@generateWithConfigAndCallback 0 }
                    if (written == 0) break
                    offset += written
                    totalWritten += written
                }
                if (cancelled.get()) 0 else 1
            }
            writeFailure?.let { error(it) }
            if (!cancelled.get()) {
                val deadline = System.currentTimeMillis() + 120_000L
                while (track.playbackHeadPosition.toLong() < totalWritten && !cancelled.get() && System.currentTimeMillis() < deadline) Thread.sleep(12)
                check(System.currentTimeMillis() < deadline || cancelled.get()) { "انتهت مهلة تشغيل صوت Supertonic." }
            }
        } finally {
            try { track.pause(); track.flush(); track.release() } catch (_: Exception) { }
            if (activeTrack === track) activeTrack = null
        }
    }

    fun stop() {
        cancelled.set(true)
        try { activeTrack?.let { it.pause(); it.flush(); it.stop() } } catch (_: Exception) { }
    }

    fun close() {
        stop()
        synchronized(lock) {
            try { tts?.release() } catch (_: Exception) { }
            tts = null
        }
    }
}
