package com.example.shadowingai

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri

/**
 * Local, curated database for real examples attached to existing app phrases.
 * Search pages are deliberately NOT stored as playable clips. Only verified,
 * playable example URLs should be inserted into phrase_examples.
 */
data class PhraseExample(
    val id: Long = 0L,
    val phraseId: String,
    val sourceId: String,
    val title: String,
    val url: String,
    val spokenText: String = "",
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val matchType: String = MATCH_EXACT,
    val verificationState: String = STATE_PENDING,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val MATCH_EXACT = "exact"
        const val MATCH_NATURAL = "natural"
        const val MATCH_CONTEXT = "context"
        const val STATE_PENDING = "pending"
        const val STATE_VERIFIED = "verified"
        const val STATE_UNAVAILABLE = "unavailable"
    }
}

data class PhraseExampleSearch(
    val phraseId: String,
    val phraseText: String,
    val sourceId: String,
    val sourceName: String,
    val searchUrl: String
)

data class PhraseExampleSource(
    val id: String,
    val name: String,
    val description: String,
    val enabled: Boolean
)

class PhraseExamplesDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE phrase_example_sources (
                source_id TEXT PRIMARY KEY NOT NULL,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                enabled INTEGER NOT NULL DEFAULT 1
            )""".trimIndent()
        )
        db.execSQL(
            """CREATE TABLE phrase_examples (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                phrase_id TEXT NOT NULL,
                source_id TEXT NOT NULL,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                spoken_text TEXT NOT NULL DEFAULT '',
                start_ms INTEGER NOT NULL DEFAULT 0,
                end_ms INTEGER NOT NULL DEFAULT 0,
                match_type TEXT NOT NULL DEFAULT 'exact',
                verification_state TEXT NOT NULL DEFAULT 'pending',
                notes TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(source_id) REFERENCES phrase_example_sources(source_id),
                UNIQUE(phrase_id, source_id, url)
            )""".trimIndent()
        )
        db.execSQL("CREATE INDEX idx_phrase_examples_phrase ON phrase_examples(phrase_id)")
        db.execSQL("CREATE INDEX idx_phrase_examples_state ON phrase_examples(verification_state)")
        createSearchTable(db)
        seedSources(db)
    }

    private fun seedSources(db: SQLiteDatabase) {
        val sources = listOf(
            PhraseExampleSource("playphrase", "PlayPhrase.me", "مقاطع حوارية من الأفلام والمسلسلات؛ تُحفظ الأمثلة بعد التحقق من المقطع.", true),
            PhraseExampleSource("yarn", "YARN", "لقطات وحوارات قصيرة؛ قد يختلف دعم التضمين حسب المقطع.", true),
            PhraseExampleSource("captionsearch", "Caption Search", "بحث في كابشن فيديوهات حقيقية مع روابط إلى لحظة النطق؛ نتائج البحث ليست مقاطع موثقة تلقائياً.", true),
            PhraseExampleSource("tcse", "TED Corpus", "بحث في نصوص آلاف محاضرات TED مع سياق وتوقيت وتشغيل من أداة TCSE الأصلية.", true),
            PhraseExampleSource("captionsearchio", "CaptionSearch.io", "فهرس بحث مستقل في قنوات يوتيوب محددة؛ البحث يتم داخل الموقع ولا توجد واجهة API عامة موثقة.", true),
            PhraseExampleSource("third_party", "مصدر ثالث", "مصدر إضافي يحدد بعد اختباره والتأكد من حقوق الاستخدام والتشغيل الداخلي.", false)
        )
        sources.forEach { source ->
            val values = ContentValues().apply {
                put("source_id", source.id)
                put("name", source.name)
                put("description", source.description)
                put("enabled", if (source.enabled) 1 else 0)
            }
            db.insertWithOnConflict("phrase_example_sources", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    private fun createSearchTable(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS phrase_example_searches (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                phrase_id TEXT NOT NULL,
                phrase_text TEXT NOT NULL,
                source_id TEXT NOT NULL,
                search_url TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(phrase_id, source_id)
            )""".trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_phrase_searches_phrase ON phrase_example_searches(phrase_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Additive migration: keep every previously saved user example.
        if (oldVersion < 2) {
            createSearchTable(db)
            val values = ContentValues().apply {
                put("source_id", "captionsearch")
                put("name", "Caption Search")
                put("description", "بحث في كابشن فيديوهات حقيقية مع روابط إلى لحظة النطق؛ نتائج البحث ليست مقاطع موثقة تلقائياً.")
                put("enabled", 1)
            }
            db.insertWithOnConflict("phrase_example_sources", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        }
        if (oldVersion < 3) {
            val additions = listOf(
                PhraseExampleSource("tcse", "TED Corpus", "بحث في نصوص آلاف محاضرات TED مع سياق وتوقيت وتشغيل من أداة TCSE الأصلية.", true),
                PhraseExampleSource("captionsearchio", "CaptionSearch.io", "فهرس بحث مستقل في قنوات يوتيوب محددة؛ البحث يتم داخل الموقع ولا توجد واجهة API عامة موثقة.", true)
            )
            additions.forEach { source ->
                val values = ContentValues().apply {
                    put("source_id", source.id); put("name", source.name)
                    put("description", source.description); put("enabled", if (source.enabled) 1 else 0)
                }
                db.insertWithOnConflict("phrase_example_sources", null, values, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
    }

    /** Preloads phrase-specific search destinations, never pretending search pages are verified clips. */
    fun seedPhraseSearches(phrases: List<Pair<String, String>>): Int {
        val db = writableDatabase
        var inserted = 0
        db.beginTransaction()
        try {
            val uniquePhrases = phrases.distinctBy { it.first }
            val now = System.currentTimeMillis()
            uniquePhrases.forEach { (phraseId, phraseText) ->
                if (phraseId.isBlank() || phraseText.isBlank()) return@forEach
                val candidates = listOf(
                    "playphrase" to "https://www.playphrase.me/#/clip-search?language=en&q=${Uri.encode(phraseText)}",
                    "captionsearch" to "https://captionsearch.app/",
                    "tcse" to "https://www.yohasebe.com/tcse/",
                    "captionsearchio" to "https://captionsearch.io/"
                )
                candidates.forEach { (sourceId, url) ->
                    val values = ContentValues().apply {
                        put("phrase_id", phraseId)
                        put("phrase_text", phraseText)
                        put("source_id", sourceId)
                        put("search_url", url)
                        put("created_at", now)
                    }
                    val result = db.insertWithOnConflict("phrase_example_searches", null, values, SQLiteDatabase.CONFLICT_IGNORE)
                    if (result != -1L) inserted++
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return inserted
    }

    fun getSearches(phraseId: String): List<PhraseExampleSearch> {
        val sql = """SELECT s.phrase_id, s.phrase_text, s.source_id, s.search_url, r.name
            FROM phrase_example_searches s
            LEFT JOIN phrase_example_sources r ON r.source_id = s.source_id
            WHERE s.phrase_id = ? ORDER BY s.source_id""".trimIndent()
        return readableDatabase.rawQuery(sql, arrayOf(phraseId)).use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(
                    PhraseExampleSearch(
                        phraseId = cursor.getString(0), phraseText = cursor.getString(1),
                        sourceId = cursor.getString(2), searchUrl = cursor.getString(3),
                        sourceName = cursor.getString(4) ?: cursor.getString(2)
                    )
                )
            }
        }
    }

    fun saveExample(example: PhraseExample): Long {
        require(example.phraseId.isNotBlank()) { "phraseId is required" }
        require(example.sourceId.isNotBlank()) { "sourceId is required" }
        require(example.title.isNotBlank()) { "title is required" }
        require(isWebUrl(example.url)) { "Only http/https example URLs are accepted" }
        require(example.startMs >= 0L && example.endMs >= 0L) { "Timestamps cannot be negative" }
        require(example.endMs == 0L || example.endMs >= example.startMs) { "endMs must be after startMs" }
        require(example.matchType in setOf(PhraseExample.MATCH_EXACT, PhraseExample.MATCH_NATURAL, PhraseExample.MATCH_CONTEXT))
        require(example.verificationState in setOf(PhraseExample.STATE_PENDING, PhraseExample.STATE_VERIFIED, PhraseExample.STATE_UNAVAILABLE))

        val now = System.currentTimeMillis()
        val values = ContentValues().apply {
            put("phrase_id", example.phraseId)
            put("source_id", example.sourceId)
            put("title", example.title.trim())
            put("url", example.url.trim())
            put("spoken_text", example.spokenText.trim())
            put("start_ms", example.startMs)
            put("end_ms", example.endMs)
            put("match_type", example.matchType)
            put("verification_state", example.verificationState)
            put("notes", example.notes.trim())
            put("created_at", example.createdAt)
            put("updated_at", now)
        }
        return writableDatabase.insertWithOnConflict(
            "phrase_examples", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    /** Returns only verified examples by default, ordered by source and title. */
    fun getExamples(phraseId: String, verifiedOnly: Boolean = true): List<PhraseExample> {
        val selection = if (verifiedOnly) "phrase_id = ? AND verification_state = ?" else "phrase_id = ?"
        val args = if (verifiedOnly) arrayOf(phraseId, PhraseExample.STATE_VERIFIED) else arrayOf(phraseId)
        return readableDatabase.query(
            "phrase_examples", null, selection, args, null, null, "source_id ASC, title COLLATE NOCASE ASC"
        ).use { cursor -> buildList { while (cursor.moveToNext()) add(cursor.toPhraseExample()) } }
    }

    fun getExampleCount(phraseId: String, verifiedOnly: Boolean = true): Int {
        val selection = if (verifiedOnly) "phrase_id = ? AND verification_state = ?" else "phrase_id = ?"
        val args = if (verifiedOnly) arrayOf(phraseId, PhraseExample.STATE_VERIFIED) else arrayOf(phraseId)
        readableDatabase.rawQuery("SELECT COUNT(*) FROM phrase_examples WHERE $selection", args).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun getSources(enabledOnly: Boolean = false): List<PhraseExampleSource> {
        val selection = if (enabledOnly) "enabled = 1" else null
        return readableDatabase.query("phrase_example_sources", null, selection, null, null, null, "name COLLATE NOCASE").use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(
                    PhraseExampleSource(
                        cursor.getString(cursor.getColumnIndexOrThrow("source_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("description")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("enabled")) == 1
                    )
                )
            }
        }
    }

    fun setExampleState(exampleId: Long, state: String): Int {
        require(state in setOf(PhraseExample.STATE_PENDING, PhraseExample.STATE_VERIFIED, PhraseExample.STATE_UNAVAILABLE))
        val values = ContentValues().apply {
            put("verification_state", state)
            put("updated_at", System.currentTimeMillis())
        }
        return writableDatabase.update("phrase_examples", values, "_id = ?", arrayOf(exampleId.toString()))
    }

    fun deleteExample(exampleId: Long): Int =
        writableDatabase.delete("phrase_examples", "_id = ?", arrayOf(exampleId.toString()))

    private fun Cursor.toPhraseExample() = PhraseExample(
        id = getLong(getColumnIndexOrThrow("_id")),
        phraseId = getString(getColumnIndexOrThrow("phrase_id")),
        sourceId = getString(getColumnIndexOrThrow("source_id")),
        title = getString(getColumnIndexOrThrow("title")),
        url = getString(getColumnIndexOrThrow("url")),
        spokenText = getString(getColumnIndexOrThrow("spoken_text")),
        startMs = getLong(getColumnIndexOrThrow("start_ms")),
        endMs = getLong(getColumnIndexOrThrow("end_ms")),
        matchType = getString(getColumnIndexOrThrow("match_type")),
        verificationState = getString(getColumnIndexOrThrow("verification_state")),
        notes = getString(getColumnIndexOrThrow("notes")),
        createdAt = getLong(getColumnIndexOrThrow("created_at")),
        updatedAt = getLong(getColumnIndexOrThrow("updated_at"))
    )

    private fun isWebUrl(value: String): Boolean =
        value.startsWith("https://", ignoreCase = true) || value.startsWith("http://", ignoreCase = true)

    companion object {
        private const val DB_NAME = "shadowing_phrase_examples.db"
        private const val DB_VERSION = 3
        @Volatile private var INSTANCE: PhraseExamplesDatabase? = null

        fun getInstance(context: Context): PhraseExamplesDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: PhraseExamplesDatabase(context).also { INSTANCE = it }
            }
    }
}
