Sherpa-ONNX v2.0.1 is bootstrapped automatically by app/build.gradle.kts.

On Gradle sync, CodeAssist downloads these official GitHub release assets into this folder if missing, then verifies SHA-256 before compilation:
- sherpa-onnx-2.0.1.aar (Android AAR; 47.2 MB)
  SHA-256: a8d09d1d32f3eb8520482c6d3d43fae674681c5b050385967c70a3c2c9bf0ee7
- sherpa-onnx-jvm-2.0.1.jar (JVM API classes; 188 KB)
  SHA-256: 8320e2457b6e38dd624fb619d3552e11ef78ffeb394622056126b16f2fd99d12

Both assets are required: the AAR alone does not expose the Kotlin/JVM API classes used by SupertonicTtsEngine.kt. No JitPack resolution is required. Internet access to github.com is needed only on the first Gradle sync.
Pocket TTS MediaPipe dependency remains enabled.
Official release: https://github.com/k2-fsa/sherpa-onnx/releases/tag/v2.0.1
