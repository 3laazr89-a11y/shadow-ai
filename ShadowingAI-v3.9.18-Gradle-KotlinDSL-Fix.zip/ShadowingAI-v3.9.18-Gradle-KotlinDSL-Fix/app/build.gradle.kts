import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Sherpa-ONNX v2.0.1 local bootstrap. CodeAssist downloads the official release assets
// once into app/libs, verifies their SHA-256, then Gradle compiles against local files.
fun ensureSherpaAsset(fileName: String, expectedSha256: String) {
    val libsDir = file("libs").apply { mkdirs() }
    val target = File(libsDir, fileName)
    fun sha256(file: File): String = MessageDigest.getInstance("SHA-256")
        .digest(file.readBytes()).joinToString("") { b: Byte -> (b.toInt() and 0xff).toString(16).padStart(2, '0') }
    if (target.isFile && sha256(target) == expectedSha256) return
    if (target.exists()) target.delete()
    val partial = File(libsDir, "$fileName.part")
    val url = URL("https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.1/$fileName")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 30000
        readTimeout = 240000
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "ShadowingAI-Gradle/3.9.18")
    }
    try {
        val status = connection.responseCode
        if (status != HttpURLConnection.HTTP_OK) throw GradleException("Sherpa-ONNX download failed: $fileName (HTTP $status). Check network access to github.com and retry Gradle sync.")
        connection.inputStream.use { input -> partial.outputStream().buffered().use { output -> input.copyTo(output) } }
        val actual = sha256(partial)
        if (actual != expectedSha256) throw GradleException("Sherpa-ONNX checksum mismatch for $fileName. Delete app/libs/$fileName.part and retry.")
        if (!partial.renameTo(target)) throw GradleException("Cannot install downloaded Sherpa-ONNX file: app/libs/$fileName")
    } finally {
        connection.disconnect()
        if (partial.exists()) partial.delete()
    }
}

// Sherpa-ONNX v2.0.1: AAR supplies Android JNI/runtime; JVM JAR supplies Kotlin API classes.
// Both files are fetched and SHA-256 verified during Gradle configuration below.
ensureSherpaAsset("sherpa-onnx-2.0.1.aar", "a8d09d1d32f3eb8520482c6d3d43fae674681c5b050385967c70a3c2c9bf0ee7")
ensureSherpaAsset("sherpa-onnx-jvm-2.0.1.jar", "8320e2457b6e38dd624fb619d3552e11ef78ffeb394622056126b16f2fd99d12")
val sherpaAar = file("libs/sherpa-onnx-2.0.1.aar")
val sherpaJvmJar = file("libs/sherpa-onnx-jvm-2.0.1.jar")
logger.lifecycle("Sherpa-ONNX local assets: AAR=${sherpaAar.length()} bytes; JVM JAR=${sherpaJvmJar.length()} bytes")

android {
    namespace = "com.example.shadowingai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.shadowingai"
        minSdk = 24
        targetSdk = 34
        ndk { abiFilters += "arm64-v8a" }
        versionCode = 38
        versionName = "3.9.18"
    }
    buildFeatures { compose = true }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        jniLibs { pickFirsts += setOf("**/libc++_shared.so") }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Required by PocketTtsEngine; keep this alongside Sherpa-ONNX.
    implementation("com.google.mediapipe:tasks-audio:1.2.2")
    // Sherpa-ONNX is supplied as a local AAR in app/libs to avoid JitPack resolution.
    implementation(files(layout.projectDirectory.file("libs/sherpa-onnx-2.0.1.aar")))
    implementation(files(layout.projectDirectory.file("libs/sherpa-onnx-jvm-2.0.1.jar")))
    debugImplementation("androidx.compose.ui:ui-tooling")
}
