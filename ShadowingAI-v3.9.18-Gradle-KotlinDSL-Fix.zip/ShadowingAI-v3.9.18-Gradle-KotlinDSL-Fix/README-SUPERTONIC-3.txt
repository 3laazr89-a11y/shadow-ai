Shadowing AI 3.9.16 – Pocket TTS + Supertonic 3

Speech engines
- Pocket TTS remains available as the default local engine.
- Supertonic 3 is added as a second local offline engine through sherpa-onnx 2.0.1.
- Edge TTS and Azure DragonHD integrations and key UI have been removed.
- Both engines stream PCM to Android AudioTrack; generated speech is not kept as permanent MP3/WAV files.

Supertonic model
- Model source: https://huggingface.co/WilburDev/supertonic-3-mobile
- Runtime: https://github.com/k2-fsa/sherpa-onnx
- License: OpenRAIL-M. Review the model LICENSE and its use restrictions before redistribution or commercial use.
- Model files are downloaded into app-private storage on first use.
- English language, 10 speaker IDs (F1-F5 and M1-M5), 5 inference steps, CPU provider, 4 threads.

Build
- Gradle downloads the official Sherpa-ONNX 2.0.1 AAR and JVM JAR directly from the GitHub release, verifies SHA-256, then adds both as explicit local file dependencies.
- ABI is arm64-v8a, matching most modern Android phones.

Important validation note
- Source-level and archive checks do not prove device inference. Run GitHub Actions, install the APK, download the Supertonic model from Settings > Speech engine, and test “I was just wondering.” on the target phone.


Build dependency note (3.9.16 fix):
Sherpa-ONNX 2.0.1 is resolved from JitPack (https://jitpack.io). The repository is declared first in settings.gradle.kts. If CodeAssist still reports a download failure, this is a repository/network access issue rather than an invalid Maven coordinate; try a normal network connection and retry Gradle sync. Pocket TTS also requires MediaPipe tasks-audio 1.2.2, which is retained in app/build.gradle.kts.
