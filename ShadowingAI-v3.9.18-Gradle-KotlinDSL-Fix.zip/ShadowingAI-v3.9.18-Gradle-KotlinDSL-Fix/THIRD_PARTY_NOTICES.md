# Third-party notices

## Microsoft Azure AI Speech

The application can send user-entered practice text to the Microsoft Azure AI Speech service when Azure DragonHD is selected. This is a network service requiring the user's own Speech resource key and region. Review Microsoft's current service terms, privacy documentation, and pricing before use. The application does not bundle Microsoft Speech SDK binaries.

## Microsoft Edge Read Aloud

Edge TTS is an unofficial online interface to Microsoft Edge Read Aloud and is not affiliated with or endorsed by Microsoft. This app includes an independent Android WebSocket client for the unofficial Edge Read Aloud interface. It requires an internet connection, does not require an Azure API key, and may stop working if Microsoft changes the private service protocol. This project is not affiliated with Microsoft.


## PocketTTS model (Kyutai) via Google MediaPipe Tasks Audio

- The app integrates the Google MediaPipe Tasks Audio Text-to-Speech runtime (`com.google.mediapipe:tasks-audio`). The runtime library is distributed under its upstream Apache 2.0 license.
- The English PocketTTS model bundle (`pocket_tts_en_int8.litertlm`) is downloaded by the user inside the app from the `litert-community/pocket-tts` Hugging Face repository. It is not bundled in the APK.
- PocketTTS model weights and voice embeddings are published by Kyutai under Creative Commons Attribution 4.0 (CC BY 4.0). Attribution: Kyutai, PocketTTS. License: https://creativecommons.org/licenses/by/4.0/ .
- Model source: https://huggingface.co/litert-community/pocket-tts . Google integration documentation: https://developers.google.com/edge/mediapipe/solutions/audio/text_to_speech/index .
