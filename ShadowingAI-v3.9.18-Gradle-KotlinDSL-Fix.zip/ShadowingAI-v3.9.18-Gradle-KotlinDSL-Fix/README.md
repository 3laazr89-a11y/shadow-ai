# Shadowing AI 3.9.18 — PocketTTS Local Speech + In-App Phrase Training

تطبيق Android أصلي بـ Kotlin وJetpack Compose للتدرب على تقليد الكلام الإنجليزي. الحد الأدنى Android 7.0 (API 24)، والبناء عبر GitHub Actions باستخدام JDK 17 وGradle 8.9.

## إصلاح 3.9.2

- استعادة عرض المصادر داخل التطبيق باستخدام Android WebView داخل نافذة بحث كاملة الشاشة.
- لم تعد أزرار المصادر تستخدم `Intent.ACTION_VIEW`، لذلك لا تحوّل المستخدم تلقائياً إلى متصفح الهاتف.
- الحفاظ على مركز المصادر الموحد وتصميمه العربي ومصادر PlayPhrase.me وYARN وTED Corpus Search Engine.
- فتح PlayPhrase برابط بحث العبارة مباشرة؛ أما YARN وTED Corpus فيفتحان داخل النافذة ويحاول التطبيق تعبئة العبارة في حقل البحث عند توفر حقل مناسب، ويمكن إدخالها يدوياً إذا لم ينجح ذلك.
- دعم تشغيل HTML5 داخل WebView مع إعدادات JavaScript وDOM storage والكوكيز اللازمة للمواقع، وإتاحة وضع ملء الشاشة الذي يطلبه مشغل الموقع.
- التنقل عبر روابط HTTP/HTTPS يبقى داخل WebView. تُحجب مخططات `intent` و`file` و`content` بدلاً من تسليمها إلى تطبيقات خارجية.
- إضافة معالجة تحرير WebView عند إغلاق النافذة، ورسالة خطأ عند تعذر تحميل الصفحة.
- الإبقاء على ميثاق حقوق المحتوى: لا تنزيل ولا استخراج ملفات ولا إعادة استضافة، ولا تجاوز لتسجيل الدخول أو قيود المصدر.
- رفع الإصدار إلى 3.9.2 ورقم البناء إلى 22.
- الحفاظ على محرك الكابشن المحلي وSQLite FTS4 واستيراد SRT/VTT وربطها بوسائط المستخدم ومشغل التوقيت، إضافة إلى المكتبة والتسجيل وTTS والتقييم والتقدم ومدرب Coach الاختياري.

## طريقة استخدام مركز المصادر

1. افتح مكتبة العبارات أو الاستوديو.
2. اختر «البحث عن أمثلة حقيقية لهذه العبارة».
3. اختر PlayPhrase أو YARN أو TED Corpus من شرائح المصادر أعلى النافذة.
4. ستُعرض صفحة المصدر داخل التطبيق. في PlayPhrase يبدأ البحث بالعبارة؛ وفي YARN وTED قد تحتاج إلى تأكيد البحث أو إدخال العبارة في حقل الموقع.
5. تشغيل الفيديو داخل WebView يعتمد على سماح الموقع بالتضمين والتشغيل داخل متصفح مدمج، وعلى توافق مشغله مع إصدار Android System WebView. إذا حظر الموقع التشغيل المضمن أو طلب تسجيل الدخول، فلن يحاول التطبيق تجاوز ذلك.
6. استخدم «حقوق المحتوى» لمراجعة الميثاق.

## ميثاق حقوق المحتوى

- لا نستضيف أو ننسخ مقاطع لا نملك حقوقها.
- لا نتجاوز تسجيل الدخول أو قيود الوصول أو التشغيل أو التضمين.
- نحافظ على اسم المصدر ورابطه، ولا ندّعي ملكية المحتوى أو ترجمته.
- لا نعرض ترخيصاً أو اسم صاحب حقوق إلا إذا كانت المعلومة موثوقة.
- ندعم ملفات المستخدم الخاصة والمحتوى المرخص والمفتوح، مع احترام شروط كل مصدر.
- نتعامل بجدية مع بلاغات أصحاب الحقوق وطلبات إزالة أي مادة مخالفة.

## محرك الكابشن المحلي

- يفهرس ملفات SRT وVTT التي يختارها المستخدم محلياً باستخدام SQLite FTS4.
- يربط كل ترجمة بملف الفيديو أو الصوت الذي يختاره المستخدم.
- يحفظ نص كل سطر وتوقيت البداية والنهاية واسم المصدر وتصنيفه.
- يبحث عن العبارة ثم الكلمات، ويعرض النتائج مع التوقيت ويفتح الوسيط المحلي داخل مشغل Android من موضع العبارة.
- لا يزحف تلقائياً إلى الإنترنت ولا ينزّل ترجمات من مواقع خارجية.

## البناء عبر GitHub Actions

يحتوي المشروع على `.github/workflows/android-build.yml`. ارفع ملفات المشروع إلى GitHub ثم شغّل **Android Debug Build** من تبويب Actions أو ادفع تغييراً إلى `main` أو `master`. عند نجاح البناء سيظهر Artifact باسم `ShadowingAI-3.9.2-debug`.

هذا Debug APK للاختبار وليس إصدار Release موقعاً للنشر.

## حالة التحقق

- تمت مراجعة نسخة 3.9.0 ومقارنة تنفيذ مركز المصادر مع نسخة 3.7.0 التي كانت تعرض المواقع داخل WebView.
- تم نقل نمط WebView المضمن إلى مركز المصادر الأحدث بدلاً من إعادة المشروع كله إلى 3.7.0.
- تم التحقق من وجود صلاحية الإنترنت في AndroidManifest.xml ومن سلامة إعدادات Compose/AndroidView المطلوبة في المشروع.
- تم فحص بنية ملفات المشروع وأرشيف ZIP بعد إنشائه. لم يتم تنفيذ Gradle assemble أو اختبار APK على هاتف Android في بيئة التحرير؛ يجب تشغيل GitHub Actions وتجربة PlayPhrase وYARN وTED فعلياً على الهاتف.

## Phrase examples database (v3.9.3)

The app now creates a local SQLite database named `shadowing_phrase_examples.db` on first launch. It is separate from the existing SharedPreferences phrase library, so phrase progress, favorites, recordings, and imported phrase assets are not migrated or overwritten.

### Tables
- `phrase_example_sources`: source registry (PlayPhrase.me, YARN, and a disabled placeholder for a third source).
- `phrase_examples`: curated examples linked by the existing `Phrase.id` value. Stores source, title, URL, spoken transcript, start/end timestamps, match classification, verification state, notes, and timestamps.

### Data integrity rules
- Only HTTP(S) URLs are accepted.
- Duplicate `(phrase_id, source_id, url)` entries are replaced rather than duplicated.
- Examples are returned as verified-only by default. Pending or unavailable entries can be inspected with `getExamples(phraseId, verifiedOnly = false)`.
- No fake clip URLs or unverified search URLs are preloaded. A source search page is not treated as a playable example.
- The database is created automatically from `MainActivity.onCreate`; no extra Gradle dependency is required.

### Main API
Use `PhraseExamplesDatabase.getInstance(context)` and its `saveExample`, `getExamples`, `getExampleCount`, `getSources`, `setExampleState`, and `deleteExample` methods. Store the exact existing phrase ID in `phraseId`.


## Version 3.9.4 — Phrase Examples UI

- Added a visible phrase-specific examples screen backed by `shadowing_phrase_examples.db`.
- Each phrase shows three verified-example slots and separate pending-review entries.
- Added manual example entry (source ID, title, URL, spoken text, match type, and timestamps).
- Added in-app WebView preview, manual verification, and deletion controls.
- The existing phrase library and caption importer remain in place.
- No sample clip URLs are fabricated or pre-marked as verified.

Build verification: ZIP structure checked; a Gradle/Android build was not run in this environment.


## Version 3.9.5 — Phrase-specific video search catalog

- Added an additive SQLite migration (database version 2) that preserves all existing user-added examples.
- On first launch after upgrading, the app creates two phrase-specific search destinations for every built-in and imported phrase: PlayPhrase.me Clip Search and Caption Search.
- The imported phrase asset currently contains 2,869 phrases; together with 12 built-in phrases, the catalog prepares 2,881 phrase entries and 5,762 search destinations.
- Search destinations are stored in a separate `phrase_example_searches` table. They are deliberately not inserted into `phrase_examples` and are never counted as verified/playable clips.
- The examples screen now shows dedicated in-app search buttons for each phrase. Open a result, identify a clip that actually says the phrase, then add the direct clip/video URL and its timestamps as a real example.
- Added Caption Search as a source. It searches YouTube captions and links to the original video at the phrase timestamp. Embedded playback remains subject to the original video's and platform's embed restrictions.
- PlayPhrase.me search links are generated per phrase. PlayPhrase.me's published fair-use policy states that it has no public or private API; the app therefore uses its normal user-facing search page and does not scrape or download clips.

### Important distinction
This release prepopulates **search destinations**, not 5,762 confirmed video clips. A result becomes a database example only after a person checks the spoken words, selects the exact video, confirms playback, and saves the direct link/timestamp. This avoids fabricating clip IDs, false matches, or bypassing source restrictions.

Build verification: source and ZIP structure checked. Gradle is not installed in the editing environment, so no Gradle build or device playback test was run.


## Version 3.9.6 — Expanded transcript discovery

- Added TED Corpus Search Engine (TCSE) and CaptionSearch.io as additional phrase discovery destinations.
- The per-phrase catalog now prepares four destinations: PlayPhrase.me, Caption Search, TED Corpus, and CaptionSearch.io. Existing rows are preserved; missing destinations are added on database version 3 upgrade.
- The examples screen uses a horizontal source strip so all destinations remain reachable on narrow phones. Search pages attempt to prefill the phrase; the learner may need to press the website's own Search button.
- CaptionSearch.io indexes a limited set of channels/videos; it is not a universal YouTube index. TCSE searches TED transcripts and is a separate educational/research tool. Neither is treated as a public app API.
- Search results are still not verified clips. A saved example must be checked for the actual spoken phrase, timestamp, and playback. This release does not claim automatic ingestion or guaranteed embedded playback.
- No existing phrase, progress, favorites, recordings, or saved examples are intentionally removed.

Build status: source edits and archive structure checked. A Gradle build and Android-device playback test were not run in this environment because Gradle/Android SDK are unavailable here.

## Version 3.9.7 — Open-weight AI phrase generation

- Added an AI phrase-generation action to the existing Add Phrase screen. It generates five original, conversational American-English phrases for the selected topic and CEFR-style level, with natural Arabic meaning and an optional pronunciation tip/IPA.
- Generated phrases are deduplicated against the existing library and saved using the app's existing phrase persistence format. Existing phrase progress, favorites, recordings, and examples are not rewritten.
- Added `POST /generate-phrases` to the existing optional Node backend. It uses the same OpenAI-compatible endpoint/model configuration as the AI coach, validates and bounds inputs/outputs, and does not accept model-provided links or video claims.
- The app derives `/generate-phrases` from the configured `/coach` endpoint. Configure the backend URL in Progress & Settings as before; the feature remains disabled until a working backend/model is configured.

### Running an open-weight model

The backend is model-provider agnostic. One supported route is Ollama with Qwen3 open-weight models (Qwen3 model weights are Apache 2.0 according to the official Qwen repository). Ollama exposes an OpenAI-compatible `/v1/chat/completions` endpoint.

Example environment for the backend host:

```bash
ollama pull qwen3:8b
AI_BASE_URL=http://127.0.0.1:11434/v1 \
AI_API_KEY=ollama \
AI_MODEL=qwen3:8b \
PORT=3000 npm start
```

Deploy the Node backend behind HTTPS and enter its public `/coach` URL in the app settings. Keep Ollama bound to localhost/private networking; do not expose port 11434 publicly. The Android app communicates only with the HTTPS backend, not directly with the model host. Model size and speed depend on the server hardware; smaller quantized Qwen3 variants may be selected by changing `AI_MODEL` to a model installed on that host.

**Important:** open-weight does not mean the model runs on the phone in this implementation. Inference runs on the server hosting Ollama. The model creates phrases; it does not establish that a phrase occurs in any video. Real-video search and clip verification remain separate.

Build verification: `node --check coach-backend/server.mjs` passed, and the new `/generate-phrases` route returned a validated HTTP 200 response in a mocked upstream-model integration test. This did not contact a live Qwen model. Android Gradle build/device test must be run by GitHub Actions and on-device; no successful APK build is claimed here.


## Version 3.9.8 — Natural American speech generation (server-side)

- Added a dedicated «صوت طبيعي» action in the phrase studio. It requests generated speech, downloads a WAV into the app cache, and plays it inside the app. The existing Android system TTS remains available as a fallback; no existing phrase, recording, progress, or examples data is replaced.
- In that release, the Node `/synthesize` gateway was connected to an optional Qwen3-TTS adapter running outside the APK. This historical provider was replaced by Kokoro in version 3.9.9.
- The app sends only the phrase text and selected accent to the TTS endpoint; it does not upload the learner's microphone recording.
- The generated voice is a candidate training reference, not a claim of indistinguishable human speech. Its American accent, reductions, rhythm, and stress still require listening tests with native speakers.

### Honest verification status

- Node backend syntax check: passed (`node --check coach-backend/server.mjs`).
- ZIP structure and source edits: checked.
- At that release, Android Gradle build, model inference, and native-listener evaluation were not run. The current Kokoro integration and its verification status are documented under version 3.9.9.


## Version 3.9.9 — Kokoro local Android TTS
- يستخدم زر نطق العبارة واجهة Android TextToSpeech المحلية، ويختار محرك Sherpa-ONNX Kokoro المثبّت على الهاتف عبر package ID الرسمي للمحرك.
- لم يعد نطق العبارات يتصل ببوابة `/synthesize` أو يتطلب خادم TTS. محرك Kokoro وملفاته يثبتها المستخدم على الهاتف؛ إن لم يوجد المحرك يستخدم التطبيق محرك Android الافتراضي.
- راجع `tts-kokoro-local/README.md` للتثبيت الأولي. قد يلزم تنزيل أوزان المحرك مرة أولى، ثم يمكن للنطق أن يعمل دون اتصال.

### التحقق
- تم فحص صياغة خادم Node وملفات الأرشيف. لم يُنفذ Gradle build أو اختبار محرك Kokoro على هاتف فعلي في هذه البيئة؛ يلزم اختبار GitHub Actions وعلى الجهاز.


## Version 3.9.11 — Kokoro bundled inside the APK

- The GitHub Actions workflow retrieves the pinned Kokoro model on the build runner, validates SHA-256, and inserts the model archive into `app/src/main/assets` before Android packaging.
- The resulting APK contains the complete Kokoro model. The installed app makes no HTTP request to fetch speech weights and cannot restart a 349 MB model download after reaching 100%.
- On first use, the app streams the bundled archive directly from APK assets, verifies SHA-256 while extracting, and installs the model into private app storage. It does not write a second compressed archive to storage.
- Later launches reuse the extracted model. If extraction is interrupted, only the temporary extraction directory is discarded; the model remains available in the APK and can be extracted again without internet.
- Audio is generated by sherpa-onnx and played from PCM memory through `AudioTrack`; no MP3/WAV files are created.
- The APK is configured for `arm64-v8a`, matching the target HONOR X8b device. Other CPU architectures need their own ABI build variant.

### Build

1. Upload this project ZIP's contents to the GitHub repository (replace the previous project files).
2. Open **Actions** and run **Shadowing AI 3.9.11 - Kokoro Bundled in APK**.
3. Wait for the model checksum step, Gradle build, and APK-embedded-model verification to pass.
4. Download the artifact `ShadowingAI-3.9.11-Kokoro-Bundled-APK`.

The model is downloaded by GitHub's build runner, not by the Android app. A GitHub Actions cache preserves the verified archive between builds. The APK is large because it includes the speech model.

### Verification status

- Source ZIP integrity and source-level structure are checked when this package is produced.
- The GitHub workflow independently verifies the model SHA-256 before packaging and verifies the same asset inside the final APK after Gradle completes.
- A successful Gradle build and real phone playback have not yet been observed; those two results must come from the Actions run and the HONOR X8b device test. No successful APK build is claimed in advance.

## Version 3.9.13 — Edge TTS + Azure DragonHD

- Added an Android-native OkHttp WebSocket client for the unofficial Microsoft Edge Read Aloud service. It synthesizes MP3 audio without an Azure API key, using the Edge Read Aloud trusted-client token and time-bucketed `Sec-MS-GEC` request value.
- Added American Edge voices: Guy, Jenny, Aria, and Andrew. Edge speech rate is applied during synthesis.
- Kept Azure Speech DragonHD as a separate provider; only DragonHD requires an Azure Speech key and region.
- Both providers route through `TtsEngineManager`; generated audio is held in a temporary cache file during playback and deleted afterwards.
- Edge Read Aloud is an unofficial, changeable online interface, not a supported Azure API. The code is integrated but has not been live-tested against Microsoft's service in this build environment. A successful GitHub Actions build and on-device network test are still required before treating it as verified.


## Version 3.9.14 — PocketTTS local neural voice

- Added PocketTTS through Google's official MediaPipe Tasks Audio Text-to-Speech API (`tasks-audio:1.2.2`).
- The app offers the English-only INT8 model bundle (`pocket_tts_en_int8.litertlm`), approximately 163 MB, downloaded on demand into the app's private files directory. The model is not embedded in the APK and is retained between launches.
- Supports the eight bundled English voice IDs: `alba`, `azelma`, `cosette`, `eponine`, `fantine`, `javert`, `jean`, and `marius`.
- PocketTTS inference is on-device CPU inference after the one-time model download; it does not need an API key or network access to synthesize speech.
- Synthesized output is mono 24 kHz float PCM converted in memory to Android PCM playback. No generated MP3/WAV file is written to the user's library or cache.
- Added an in-app model download control and a test phrase (`I was just wondering.`). PocketTTS is the default engine for fresh installs. Edge TTS and Azure DragonHD remain selectable and their existing code paths are retained.
- Model attribution: Kyutai PocketTTS, CC BY 4.0. See `THIRD_PARTY_NOTICES.md`.

### Verification status for 3.9.14

- Source-level checks and ZIP integrity checks are performed when preparing this archive.
- This environment does not have Gradle/Android SDK available, so no Android APK build, native MediaPipe initialization, model download on a phone, or audible device playback is claimed. Run the included GitHub Actions workflow, then download the model and test the sample phrase on the target phone before treating the engine as validated.


## إصلاح تبعية Sherpa-ONNX 3.9.18

هذه الحزمة تحمل اسماً جذرياً جديداً لتجنب متابعة بناء مجلد 3.9.14 القديم. افتح مجلد `ShadowingAI-v3.9.18-Sherpa-Classpath-Fix` نفسه في CodeAssist. أثناء تهيئة Gradle يتم تنزيل ملف AAR وملف JVM JAR الرسميين والتحقق من SHA-256، ثم إضافتهما كتبعيتين محليتين منفصلتين. يلزم اتصال يعمل مع GitHub أثناء أول Gradle Sync.


## Build note (3.9.18)
The GitHub Actions workflow downloads the official Sherpa-ONNX v2.0.1 AAR and JVM JAR before Gradle starts, verifies both SHA-256 checksums, then builds the APK. This avoids relying on CodeAssist to download the large native dependency during Gradle configuration. Pocket TTS and MediaPipe remain included.
